export type CurrencyInfo = {
  code: string;
  symbol: string;
  label: string;
  locale: string;
};

export const CURRENCIES: CurrencyInfo[] = [
  { code: "₽", symbol: "₽", label: "Российский рубль", locale: "ru-RU" },
  { code: "BYN", symbol: "BYN", label: "Белорусский рубль", locale: "be-BY" },
  { code: "€", symbol: "€", label: "Евро", locale: "de-DE" },
  { code: "$", symbol: "$", label: "Доллар США", locale: "en-US" },
];

export function currencyInfo(code: string): CurrencyInfo {
  return CURRENCIES.find((c) => c.code === code) ?? CURRENCIES[0]!;
}
