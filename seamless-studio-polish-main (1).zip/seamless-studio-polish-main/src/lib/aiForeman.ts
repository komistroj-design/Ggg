import type { Project, ProjectEntry } from "@/lib/types";
import type { Language } from "@/lib/types";

type ChatMessage = { role: "user" | "assistant"; content: string };

type ProjectContext = {
  name: string;
  description: string;
  status: string;
  contractSum: number;
  paidByClient: number;
  workerPayouts: number;
  materialsTotal: number;
  worksTotal: number;
  balance: number;
  netBalance: number;
  includesVat: boolean;
  includesTax: boolean;
  vatAmount: number;
  taxAmount: number;
  currency: string;
  pauseReason: string;
  materials: {
    name: string;
    unit: string;
    quantity: number;
    price: number;
    total: number;
    status?: string | undefined;
  }[];
  works: {
    name: string;
    unit: string;
    quantity: number;
    price: number;
    total: number;
    paid?: boolean | undefined;
  }[];
};

export function buildContext(
  project: Project,
  materials: ProjectEntry[],
  works: ProjectEntry[],
): ProjectContext {
  return {
    name: project.name,
    description: project.description,
    status: project.status,
    contractSum: project.contractSum,
    paidByClient: project.paidByClient,
    workerPayouts: project.workerPayouts,
    materialsTotal: project.materialsTotal,
    worksTotal: project.worksTotal,
    balance: project.balance,
    netBalance: project.netBalance,
    includesVat: project.includesVat,
    includesTax: project.includesTax,
    vatAmount: project.vatAmount,
    taxAmount: project.taxAmount,
    currency: project.currency,
    pauseReason: project.pauseReason,
    materials: materials.map((e) => ({
      name: e.name,
      unit: e.unit,
      quantity: e.quantity,
      price: e.price,
      total: e.total,
      status: e.status,
    })),
    works: works.map((e) => ({
      name: e.name,
      unit: e.unit,
      quantity: e.quantity,
      price: e.price,
      total: e.total,
      paid: e.paid,
    })),
  };
}

function money(n: number, currency: string): string {
  const rounded = Math.round(n).toLocaleString("ru-RU");
  if (currency === "$") return `$${rounded}`;
  if (currency === "€") return `${rounded} €`;
  if (currency === "BYN") return `${rounded} BYN`;
  return `${rounded} ₽`;
}

const KEYWORDS: Record<string, string[]> = {
  volume: [
    "объем",
    "расход",
    "количеств",
    "сколько нужн",
    "рассчит",
    "calculate",
    "volume",
    "how much",
    "quantity",
    "estimate",
  ],
  price: ["цена", "цен", "стоим", "сколько стоит", "price", "cost", "market"],
  review: ["проверь", "состав", "чего не хвата", "анализ", "review", "missing", "check", "analyze"],
  balance: ["баланс", "долг", "денег", "оплач", "balance", "debt", "money", "paid", "budget"],
  status: ["статус", "пауз", "progress", "status", "paused", "done"],
};

function matchCategory(text: string): string {
  const lower = text.toLowerCase();
  for (const [cat, words] of Object.entries(KEYWORDS)) {
    if (words.some((w) => lower.includes(w))) return cat;
  }
  return "general";
}

function analyzeVolume(ctx: ProjectContext, lang: Language): string {
  if (lang === "en") {
    const lines: string[] = ["Material volume analysis:"];
    lines.push("");
    ctx.works.forEach((w) => {
      lines.push(
        `• ${w.name} — ${w.quantity} ${w.unit} at ${money(w.price, ctx.currency)}/unit = ${money(w.total, ctx.currency)}`,
      );
    });
    if (ctx.materials.length > 0) {
      lines.push("");
      lines.push("Current materials:");
      ctx.materials.forEach((m) => {
        lines.push(
          `• ${m.name} — ${m.quantity} ${m.unit} at ${money(m.price, ctx.currency)} (${m.status ?? "planned"})`,
        );
      });
    }
    const planned = ctx.materials.filter(
      (m) => m.status !== "Закуплено и доставлено" && m.status !== "Purchased & delivered",
    );
    if (planned.length > 0) {
      lines.push("");
      lines.push(
        `Not yet delivered: ${planned.length} position(s). Verify quantities with suppliers before ordering.`,
      );
    }
    return lines.join("\n");
  }
  const lines: string[] = ["Анализ объемов материалов:"];
  lines.push("");
  ctx.works.forEach((w) => {
    lines.push(
      `• ${w.name} — ${w.quantity} ${w.unit} по ${money(w.price, ctx.currency)}/ед = ${money(w.total, ctx.currency)}`,
    );
  });
  if (ctx.materials.length > 0) {
    lines.push("");
    lines.push("Текущие материалы:");
    ctx.materials.forEach((m) => {
      lines.push(
        `• ${m.name} — ${m.quantity} ${m.unit} по ${money(m.price, ctx.currency)} (${m.status ?? "планируется"})`,
      );
    });
  }
  const planned = ctx.materials.filter((m) => m.status !== "Закуплено и доставлено");
  if (planned.length > 0) {
    lines.push("");
    lines.push(
      `Еще не доставлено: ${planned.length} поз. Уточните объемы у поставщика перед заказом.`,
    );
  }
  return lines.join("\n");
}

function analyzePrice(ctx: ProjectContext, lang: Language): string {
  if (lang === "en") {
    const lines: string[] = ["Price overview for this site:"];
    lines.push("");
    ctx.materials.forEach((m) => {
      lines.push(
        `• ${m.name}: ${money(m.price, ctx.currency)}/${m.unit} (${m.quantity} ${m.unit})`,
      );
    });
    ctx.works.forEach((w) => {
      lines.push(`• ${w.name}: ${money(w.price, ctx.currency)}/${w.unit}`);
    });
    lines.push("");
    lines.push(`Materials total: ${money(ctx.materialsTotal, ctx.currency)}`);
    lines.push(`Works total: ${money(ctx.worksTotal, ctx.currency)}`);
    lines.push("Note: market prices fluctuate. Confirm current rates with suppliers.");
    return lines.join("\n");
  }
  const lines: string[] = ["Обзор цен по объекту:"];
  lines.push("");
  ctx.materials.forEach((m) => {
    lines.push(`• ${m.name}: ${money(m.price, ctx.currency)}/${m.unit} (${m.quantity} ${m.unit})`);
  });
  ctx.works.forEach((w) => {
    lines.push(`• ${w.name}: ${money(w.price, ctx.currency)}/${w.unit}`);
  });
  lines.push("");
  lines.push(`Итого материалы: ${money(ctx.materialsTotal, ctx.currency)}`);
  lines.push(`Итого работы: ${money(ctx.worksTotal, ctx.currency)}`);
  lines.push("Цены на рынке меняются — уточняйте актуальные у поставщиков.");
  return lines.join("\n");
}

function analyzeReview(ctx: ProjectContext, lang: Language): string {
  if (lang === "en") {
    const lines: string[] = ["Site review:"];
    lines.push("");
    const delivered = ctx.materials.filter(
      (m) => m.status === "Закуплено и доставлено" || m.status === "Purchased & delivered",
    );
    const planned = ctx.materials.filter(
      (m) => m.status !== "Закуплено и доставлено" && m.status !== "Purchased & delivered",
    );
    const paidWorks = ctx.works.filter((w) => w.paid);
    const unpaidWorks = ctx.works.filter((w) => !w.paid);
    lines.push(
      `Materials: ${ctx.materials.length} total — ${delivered.length} delivered, ${planned.length} pending.`,
    );
    lines.push(
      `Works: ${ctx.works.length} total — ${paidWorks.length} paid, ${unpaidWorks.length} unpaid.`,
    );
    if (planned.length > 0) {
      lines.push("");
      lines.push("Pending materials:");
      planned.forEach((m) => lines.push(`  — ${m.name} (${m.quantity} ${m.unit})`));
    }
    if (unpaidWorks.length > 0) {
      lines.push("");
      lines.push("Unpaid works:");
      unpaidWorks.forEach((w) => lines.push(`  — ${w.name}: ${money(w.total, ctx.currency)}`));
    }
    if (ctx.balance < 0) {
      lines.push("");
      lines.push(`Warning: site is in debt by ${money(Math.abs(ctx.balance), ctx.currency)}.`);
    }
    return lines.join("\n");
  }
  const lines: string[] = ["Проверка состава объекта:"];
  lines.push("");
  const delivered = ctx.materials.filter((m) => m.status === "Закуплено и доставлено");
  const planned = ctx.materials.filter((m) => m.status !== "Закуплено и доставлено");
  const paidWorks = ctx.works.filter((w) => w.paid);
  const unpaidWorks = ctx.works.filter((w) => !w.paid);
  lines.push(
    `Материалы: всего ${ctx.materials.length} — доставлено ${delivered.length}, ожидает ${planned.length}.`,
  );
  lines.push(
    `Работы: всего ${ctx.works.length} — оплачено ${paidWorks.length}, не оплачено ${unpaidWorks.length}.`,
  );
  if (planned.length > 0) {
    lines.push("");
    lines.push("Ожидают закупки:");
    planned.forEach((m) => lines.push(`  — ${m.name} (${m.quantity} ${m.unit})`));
  }
  if (unpaidWorks.length > 0) {
    lines.push("");
    lines.push("Неоплаченные работы:");
    unpaidWorks.forEach((w) => lines.push(`  — ${w.name}: ${money(w.total, ctx.currency)}`));
  }
  if (ctx.balance < 0) {
    lines.push("");
    lines.push(`Внимание: объект в долгу на ${money(Math.abs(ctx.balance), ctx.currency)}.`);
  }
  return lines.join("\n");
}

function analyzeBalance(ctx: ProjectContext, lang: Language): string {
  if (lang === "en") {
    const lines: string[] = ["Financial summary:"];
    lines.push("");
    lines.push(`Contract: ${money(ctx.contractSum, ctx.currency)}`);
    lines.push(`Paid by client: ${money(ctx.paidByClient, ctx.currency)}`);
    lines.push(`Worker payouts: ${money(ctx.workerPayouts, ctx.currency)}`);
    lines.push(`Materials: ${money(ctx.materialsTotal, ctx.currency)}`);
    lines.push(`Works: ${money(ctx.worksTotal, ctx.currency)}`);
    lines.push(`Balance: ${money(ctx.balance, ctx.currency)}`);
    if (ctx.includesVat) lines.push(`VAT 20% (incl.): ${money(ctx.vatAmount, ctx.currency)}`);
    if (ctx.includesTax) lines.push(`Tax 20%: ${money(ctx.taxAmount, ctx.currency)}`);
    lines.push(`Net balance: ${money(ctx.netBalance, ctx.currency)}`);
    if (ctx.netBalance < 0) {
      lines.push("");
      lines.push(
        `The site is running at a loss of ${money(Math.abs(ctx.netBalance), ctx.currency)}. Review expenses.`,
      );
    }
    return lines.join("\n");
  }
  const lines: string[] = ["Финансовая сводка:"];
  lines.push("");
  lines.push(`Договор: ${money(ctx.contractSum, ctx.currency)}`);
  lines.push(`Внесено заказчиком: ${money(ctx.paidByClient, ctx.currency)}`);
  lines.push(`Выплаты рабочим: ${money(ctx.workerPayouts, ctx.currency)}`);
  lines.push(`Материалы: ${money(ctx.materialsTotal, ctx.currency)}`);
  lines.push(`Работы: ${money(ctx.worksTotal, ctx.currency)}`);
  lines.push(`Баланс: ${money(ctx.balance, ctx.currency)}`);
  if (ctx.includesVat) lines.push(`НДС 20% (в т.ч.): ${money(ctx.vatAmount, ctx.currency)}`);
  if (ctx.includesTax) lines.push(`Налог 20%: ${money(ctx.taxAmount, ctx.currency)}`);
  lines.push(`Чистый остаток: ${money(ctx.netBalance, ctx.currency)}`);
  if (ctx.netBalance < 0) {
    lines.push("");
    lines.push(
      `Объект в убытке на ${money(Math.abs(ctx.netBalance), ctx.currency)}. Проверьте расходы.`,
    );
  }
  return lines.join("\n");
}

function analyzeStatus(ctx: ProjectContext, lang: Language): string {
  if (lang === "en") {
    const lines: string[] = [`Status: ${ctx.status}`];
    if (ctx.pauseReason) {
      lines.push(`Pause reason: ${ctx.pauseReason}`);
    }
    const allWorksPaid = ctx.works.length > 0 && ctx.works.every((w) => w.paid);
    const allMaterialsDelivered =
      ctx.materials.length > 0 &&
      ctx.materials.every(
        (m) => m.status === "Закуплено и доставлено" || m.status === "Purchased & delivered",
      );
    if (allWorksPaid && allMaterialsDelivered) {
      lines.push("All works paid and materials delivered — ready to complete.");
    } else {
      if (!allMaterialsDelivered) lines.push("Some materials still pending delivery.");
      if (!allWorksPaid) lines.push("Some works still unpaid.");
    }
    return lines.join("\n");
  }
  const lines: string[] = [`Статус: ${ctx.status}`];
  if (ctx.pauseReason) {
    lines.push(`Причина паузы: ${ctx.pauseReason}`);
  }
  const allWorksPaid = ctx.works.length > 0 && ctx.works.every((w) => w.paid);
  const allMaterialsDelivered =
    ctx.materials.length > 0 && ctx.materials.every((m) => m.status === "Закуплено и доставлено");
  if (allWorksPaid && allMaterialsDelivered) {
    lines.push("Все работы оплачены и материалы доставлены — можно завершать.");
  } else {
    if (!allMaterialsDelivered) lines.push("Часть материалов еще не доставлена.");
    if (!allWorksPaid) lines.push("Часть работ еще не оплачена.");
  }
  return lines.join("\n");
}

function analyzeGeneral(ctx: ProjectContext, lang: Language, userText: string): string {
  if (lang === "en") {
    return [
      `Site "${ctx.name}":`,
      `  Contract: ${money(ctx.contractSum, ctx.currency)}`,
      `  Balance: ${money(ctx.balance, ctx.currency)}`,
      `  Materials: ${ctx.materials.length} (${money(ctx.materialsTotal, ctx.currency)})`,
      `  Works: ${ctx.works.length} (${money(ctx.worksTotal, ctx.currency)})`,
      "",
      "I can analyze volumes, prices, finances, or review the work list. Ask me about any aspect.",
    ].join("\n");
  }
  return [
    `Объект «${ctx.name}»:`,
    `  Договор: ${money(ctx.contractSum, ctx.currency)}`,
    `  Баланс: ${money(ctx.balance, ctx.currency)}`,
    `  Материалы: ${ctx.materials.length} поз. (${money(ctx.materialsTotal, ctx.currency)})`,
    `  Работы: ${ctx.works.length} поз. (${money(ctx.worksTotal, ctx.currency)})`,
    "",
    "Могу проанализировать объемы, цены, финансы или проверить состав работ. Спросите о любом аспекте.",
  ].join("\n");
}

export function generateReply(
  ctx: ProjectContext,
  messages: ChatMessage[],
  lang: Language,
): string {
  const lastUserMsg = [...messages].reverse().find((m) => m.role === "user");
  const userText = lastUserMsg?.content ?? "";

  // If there's prior conversation context, use it; otherwise answer fresh
  const category = matchCategory(userText);

  switch (category) {
    case "volume":
      return analyzeVolume(ctx, lang);
    case "price":
      return analyzePrice(ctx, lang);
    case "review":
      return analyzeReview(ctx, lang);
    case "balance":
      return analyzeBalance(ctx, lang);
    case "status":
      return analyzeStatus(ctx, lang);
    default:
      return analyzeGeneral(ctx, lang, userText);
  }
}

/**
 * Stream a reply token-by-token to simulate a live AI assistant.
 * The analyzer runs entirely client-side — no external API keys needed.
 */
export function streamReply(
  ctx: ProjectContext,
  messages: ChatMessage[],
  lang: Language,
  onChunk: (text: string) => void,
  signal?: AbortSignal,
): Promise<string> {
  const full = generateReply(ctx, messages, lang);
  const tokens = full.split(/(\s+)/);

  return new Promise((resolve, reject) => {
    let i = 0;
    const interval = setInterval(() => {
      if (signal?.aborted) {
        clearInterval(interval);
        reject(new DOMException("Aborted", "AbortError"));
        return;
      }
      if (i >= tokens.length) {
        clearInterval(interval);
        resolve(full);
        return;
      }
      const chunk = tokens[i] ?? "";
      onChunk(chunk);
      i++;
    }, 20);
  });
}
