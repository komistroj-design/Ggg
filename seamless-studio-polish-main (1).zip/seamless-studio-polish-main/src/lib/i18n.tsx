import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { translations, type TranslationDict } from "@/lib/translations";
import type { Language } from "@/lib/types";

type I18nContextValue = {
  lang: Language;
  setLang: (lang: Language) => void;
  t: (key: string, vars?: Record<string, string | number>) => string;
};

const I18nContext = createContext<I18nContextValue | null>(null);

function resolveKey(dict: TranslationDict, key: string): string | undefined {
  const parts = key.split(".");
  let node: unknown = dict;
  for (const part of parts) {
    if (typeof node !== "object" || node === null) return undefined;
    node = (node as Record<string, unknown>)[part];
  }
  return typeof node === "string" ? node : undefined;
}

function interpolate(template: string, vars?: Record<string, string | number>): string {
  if (!vars) return template;
  return template.replace(/\{\{(\w+)\}\}/g, (_, name) => {
    const value = vars[name];
    return value === undefined ? `{{${name}}}` : String(value);
  });
}

export function I18nProvider({
  children,
  lang,
  setLang,
}: {
  children: ReactNode;
  lang: Language;
  setLang: (lang: Language) => void;
}) {
  const t = useCallback(
    (key: string, vars?: Record<string, string | number>) => {
      const dict = translations[lang] as TranslationDict;
      const template =
        resolveKey(dict, key) ?? resolveKey(translations.ru as TranslationDict, key) ?? key;
      return interpolate(template, vars);
    },
    [lang],
  );

  const value = useMemo(() => ({ lang, setLang, t }), [lang, setLang, t]);
  return <I18nContext.Provider value={value}>{children}</I18nContext.Provider>;
}

export function useI18n(): I18nContextValue {
  const ctx = useContext(I18nContext);
  if (!ctx) throw new Error("useI18n must be used within I18nProvider");
  return ctx;
}

export function statusLabel(status: string, lang: Language): string {
  const t = translations[lang];
  if (status === "В работе" || status === "In progress") return t.status.inProgress;
  if (status === "На паузе" || status === "Paused") return t.status.paused;
  if (status === "Выполнено" || status === "Done") return t.status.done;
  return t.status.noStatus;
}

export function useStatusLabels() {
  const { t, lang } = useI18n();
  return (status: string) => statusLabel(status, lang) || t("status.noStatus");
}

export function useTranslateStatus() {
  const { lang } = useI18n();
  return (status: string) => statusLabel(status, lang);
}

export function useStatusNameToKey() {
  return (status: string) => {
    if (status === "В работе" || status === "In progress") return "status.inProgress";
    if (status === "На паузе" || status === "Paused") return "status.paused";
    if (status === "Выполнено" || status === "Done") return "status.done";
    return "status.noStatus";
  };
}

export function canonicalStatus(status: string): string {
  if (status === "In progress") return "В работе";
  if (status === "Paused") return "На паузе";
  if (status === "Done") return "Выполнено";
  return status;
}

export function localizeStatus(status: string, lang: Language): string {
  return statusLabel(status, lang);
}

// Hook returning a function that takes raw stored status (ru) and returns localized label
export function useLocalizedStatus() {
  const { lang } = useI18n();
  return (status: string) => statusLabel(status, lang);
}
