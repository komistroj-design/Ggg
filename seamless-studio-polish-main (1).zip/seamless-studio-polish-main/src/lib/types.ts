export type ObjectRow = {
  id: string;
  user_id: string | null;
  name: string;
  contract_sum: number;
  paid_by_client: number;
  worker_payouts: number;
  description: string;
  status: string;
  pause_reason?: string | undefined;
  includes_vat?: boolean | undefined;
  includes_tax?: boolean | undefined;
  currency?: string | undefined;
  created_at?: string | undefined;
};

export type EntryRow = {
  id: string;
  object_id: string;
  name: string;
  unit: string;
  quantity: number;
  price: number;
  total: number;
  status?: string | undefined;
  paid?: boolean | undefined;
  created_at?: string | undefined;
};

export type FormValues = Record<string, string | number | boolean>;

export type SiteData = {
  objects: ObjectRow[];
  materials: EntryRow[];
  works: EntryRow[];
};

export type EntryKind = "materials" | "works";

export type Project = {
  id: string;
  name: string;
  description: string;
  contractSum: number;
  paidByClient: number;
  workerPayouts: number;
  materialsTotal: number;
  worksTotal: number;
  balance: number;
  netBalance: number;
  vatAmount: number;
  taxAmount: number;
  status: string;
  pauseReason: string;
  includesVat: boolean;
  includesTax: boolean;
  currency: string;
  isDone: boolean;
  isPaused: boolean;
  inDebt: boolean;
};

export type ProjectEntry = {
  id: string;
  name: string;
  unit: string;
  quantity: number;
  price: number;
  total: number;
  status?: string | undefined;
  paid?: boolean | undefined;
};

export type Language = "ru" | "en";
export type ThemePref = "dark" | "light" | "system";
export type CurrencyCode = "$" | "€" | "₽" | "BYN";

export type Settings = {
  language: Language;
  theme: ThemePref;
  currency: CurrencyCode;
};
