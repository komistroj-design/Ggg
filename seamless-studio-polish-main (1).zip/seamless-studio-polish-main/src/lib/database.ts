import { supabase } from "@/lib/supabase";
import type { EntryKind, EntryRow, FormValues, ObjectRow, SiteData } from "@/lib/types";

const SAVE_ERROR_RU = "Не удалось сохранить запись. Проверьте данные и попробуйте снова.";
const SAVE_ERROR_EN = "Failed to save. Check the data and try again.";

export type ObjectInput = {
  [K in keyof Omit<ObjectRow, "id" | "user_id" | "created_at">]-?: Exclude<ObjectRow[K], undefined>;
};
export type EntryInput = Pick<EntryRow, "name" | "unit" | "quantity" | "price">;

/** Empty, missing or non-numeric amounts are stored as 0 so the database never rejects them. */
export function toAmount(value: unknown): number {
  if (value === undefined || value === null || value === "") return 0;
  const n =
    typeof value === "number" ? value : Number(String(value).replace(/\s/g, "").replace(",", "."));
  return Number.isFinite(n) && n >= 0 ? n : 0;
}

export function objectInputFrom(values: FormValues): ObjectInput {
  return {
    name: String(values["name"] ?? "").trim(),
    contract_sum: toAmount(values["contract_sum"]),
    paid_by_client: toAmount(values["paid_by_client"]),
    worker_payouts: toAmount(values["worker_payouts"]),
    description: String(values["description"] ?? ""),
    status: String(values["status"] || "В работе"),
    pause_reason: String(values["pause_reason"] ?? ""),
    includes_vat: Boolean(values["includes_vat"] ?? false),
    includes_tax: Boolean(values["includes_tax"] ?? false),
    currency: String(values["currency"] ?? "₽"),
  };
}

export function entryInputFrom(values: FormValues): EntryInput {
  return {
    name: String(values["name"] ?? "").trim(),
    unit: String(values["unit"] ?? "").trim(),
    quantity: toAmount(values["quantity"]),
    price: toAmount(values["price"]),
  };
}

function saveErrorMessage(): string {
  return typeof navigator !== "undefined" && navigator.language.startsWith("en")
    ? SAVE_ERROR_EN
    : SAVE_ERROR_RU;
}

async function currentUserId(): Promise<string> {
  const { data } = await supabase.auth.getSession();
  const id = data.session?.user.id;
  if (!id) throw new Error(saveErrorMessage());
  return id;
}

export async function fetchSiteData(): Promise<SiteData> {
  const [objects, materials, works] = await Promise.all([
    supabase.from("objects").select("*").order("created_at", { ascending: true }),
    supabase.from("materials").select("*").order("created_at", { ascending: true }),
    supabase.from("works").select("*").order("created_at", { ascending: true }),
  ]);

  const failed = [objects, materials, works].find((result) => result.error);
  if (failed?.error) {
    console.error(failed.error);
    throw new Error(failed.error.message);
  }

  return {
    objects: (objects.data ?? []) as ObjectRow[],
    materials: (materials.data ?? []) as EntryRow[],
    works: (works.data ?? []) as EntryRow[],
  };
}

export async function insertObject(values: ObjectInput): Promise<void> {
  const user_id = await currentUserId();
  const { error } = await supabase.from("objects").insert({ ...values, user_id });
  if (error) {
    console.error(error);
    throw new Error(saveErrorMessage());
  }
}

export async function updateObject(id: string, values: ObjectInput): Promise<void> {
  const { error } = await supabase.from("objects").update(values).eq("id", id);
  if (error) {
    console.error(error);
    throw new Error(saveErrorMessage());
  }
}

export async function deleteObject(id: string): Promise<void> {
  const { error } = await supabase.from("objects").delete().eq("id", id);
  if (error) {
    console.error(error);
    throw new Error(saveErrorMessage());
  }
}

export async function insertEntry(
  kind: EntryKind,
  objectId: string,
  values: EntryInput,
): Promise<void> {
  const user_id = await currentUserId();
  const row = { ...values, object_id: objectId, user_id };
  const { error } =
    kind === "materials"
      ? await supabase.from("materials").insert(row)
      : await supabase.from("works").insert(row);
  if (error) {
    console.error(error);
    throw new Error(saveErrorMessage());
  }
}

export async function updateMaterialStatus(id: string, status: string): Promise<void> {
  const { error } = await supabase.from("materials").update({ status }).eq("id", id);
  if (error) {
    console.error(error);
    throw new Error(saveErrorMessage());
  }
}

export async function updateWorkPaid(id: string, paid: boolean): Promise<void> {
  const { error } = await supabase.from("works").update({ paid }).eq("id", id);
  if (error) {
    console.error(error);
    throw new Error(saveErrorMessage());
  }
}

export async function deleteEntry(kind: EntryKind, id: string): Promise<void> {
  const { error } =
    kind === "materials"
      ? await supabase.from("materials").delete().eq("id", id)
      : await supabase.from("works").delete().eq("id", id);
  if (error) {
    console.error(error);
    throw new Error(saveErrorMessage());
  }
}

export async function fetchSettings(
  userId: string,
): Promise<{ language: "ru" | "en"; theme: "dark" | "light" | "system"; currency: string } | null> {
  const { data, error } = await supabase
    .from("user_settings")
    .select("language, theme, currency")
    .eq("user_id", userId)
    .maybeSingle();
  if (error) {
    console.error(error);
    return null;
  }
  return data as {
    language: "ru" | "en";
    theme: "dark" | "light" | "system";
    currency: string;
  } | null;
}

export async function upsertSettings(
  userId: string,
  settings: { language: "ru" | "en"; theme: "dark" | "light" | "system"; currency: string },
): Promise<void> {
  const { error } = await supabase
    .from("user_settings")
    .upsert(
      { user_id: userId, ...settings, updated_at: new Date().toISOString() },
      { onConflict: "user_id" },
    );
  if (error) {
    console.error(error);
  }
}
