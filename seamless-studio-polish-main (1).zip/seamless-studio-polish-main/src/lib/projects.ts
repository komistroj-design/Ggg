import { STATUS_DONE, STATUS_PAUSED } from "@/lib/recordConfig";
import type { EntryRow, ObjectRow, Project, ProjectEntry, SiteData } from "@/lib/types";

const num = (value: unknown): number => Number(value) || 0;

function sumTotals(rows: EntryRow[]): number {
  return rows.reduce((sum, row) => sum + num(row.total), 0);
}

// Standard reverse VAT: VAT 20% is 1/6 of the VAT-inclusive total.
function vatFromTotal(total: number): number {
  return total / 6;
}

export function toProjects(data: SiteData): Project[] {
  return data.objects.map((object: ObjectRow) => {
    const materials = data.materials.filter((row) => row.object_id === object.id);
    const works = data.works.filter((row) => row.object_id === object.id);
    const materialsTotal = sumTotals(materials);
    const worksTotal = sumTotals(works);
    const totalCosts = num(object.worker_payouts) + materialsTotal + worksTotal;
    const balance = num(object.paid_by_client) - totalCosts;

    const includesVat = Boolean(object.includes_vat);
    const includesTax = Boolean(object.includes_tax);
    const vatAmount = includesVat ? vatFromTotal(num(object.contract_sum)) : 0;
    const taxAmount = includesTax ? num(object.contract_sum) * 0.2 : 0;
    const netBalance = balance - vatAmount - taxAmount;

    return {
      id: object.id,
      name: object.name,
      description: object.description ?? "",
      contractSum: num(object.contract_sum),
      paidByClient: num(object.paid_by_client),
      workerPayouts: num(object.worker_payouts),
      materialsTotal,
      worksTotal,
      balance,
      netBalance,
      vatAmount,
      taxAmount,
      status: object.status,
      pauseReason: object.pause_reason ?? "",
      includesVat,
      includesTax,
      currency: object.currency ?? "₽",
      isDone: object.status === STATUS_DONE,
      isPaused: object.status === STATUS_PAUSED,
      inDebt: netBalance < 0,
    };
  });
}

export function toEntries(rows: EntryRow[], objectId: string): ProjectEntry[] {
  return rows
    .filter((row) => row.object_id === objectId)
    .map((row) => ({
      id: row.id,
      name: row.name,
      unit: row.unit ?? "",
      quantity: num(row.quantity),
      price: num(row.price),
      total: num(row.total),
      status: row.status,
      paid: row.paid,
    }));
}
