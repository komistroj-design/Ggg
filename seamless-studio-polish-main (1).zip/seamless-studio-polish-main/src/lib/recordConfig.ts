export const STATUS_DONE = "Выполнено";
export const STATUS_IN_PROGRESS = "В работе";
export const STATUS_PAUSED = "На паузе";

export const STATUS_PLANNED = "Планируется";
export const STATUS_DELIVERED = "Закуплено и доставлено";

export type FieldConfig = {
  key: string;
  labelKey: string;
  type: "text" | "number" | "select" | "boolean";
  required?: boolean;
  placeholder?: string;
  options?: readonly string[];
  defaultValue?: string;
};

export type FormConfig = {
  titleKey: string;
  fields: FieldConfig[];
};

export const OBJECT_FORM: FormConfig = {
  titleKey: "form.object.title",
  fields: [
    {
      key: "name",
      labelKey: "form.object.name",
      type: "text",
      required: true,
      placeholder: "Держинского 15",
    },
    {
      key: "contract_sum",
      labelKey: "form.object.contractSum",
      type: "number",
      required: true,
      placeholder: "0",
    },
    {
      key: "paid_by_client",
      labelKey: "form.object.paidByClient",
      type: "number",
      placeholder: "0",
    },
    {
      key: "worker_payouts",
      labelKey: "form.object.workerPayouts",
      type: "number",
      placeholder: "0",
    },
    {
      key: "status",
      labelKey: "form.object.status",
      type: "select",
      options: [STATUS_IN_PROGRESS, STATUS_PAUSED, STATUS_DONE],
      defaultValue: STATUS_IN_PROGRESS,
    },
    { key: "includes_vat", labelKey: "form.object.includesVat", type: "boolean" },
    { key: "includes_tax", labelKey: "form.object.includesTax", type: "boolean" },
    {
      key: "description",
      labelKey: "form.object.description",
      type: "text",
      placeholder: "Текущий ремонт фасада",
    },
    { key: "pause_reason", labelKey: "form.object.pauseReason", type: "text", placeholder: "" },
  ],
};

export const MATERIAL_FORM: FormConfig = {
  titleKey: "form.material.title",
  fields: [
    {
      key: "name",
      labelKey: "form.material.name",
      type: "text",
      required: true,
      placeholder: "Цемент М500",
    },
    { key: "unit", labelKey: "form.material.unit", type: "text", placeholder: "мешок" },
    {
      key: "quantity",
      labelKey: "form.material.quantity",
      type: "number",
      required: true,
      placeholder: "0",
    },
    {
      key: "price",
      labelKey: "form.material.price",
      type: "number",
      required: true,
      placeholder: "0",
    },
  ],
};

export const WORK_FORM: FormConfig = {
  titleKey: "form.work.title",
  fields: [
    {
      key: "name",
      labelKey: "form.work.name",
      type: "text",
      required: true,
      placeholder: "Кладка стен",
    },
    { key: "unit", labelKey: "form.work.unit", type: "text", placeholder: "м²" },
    {
      key: "quantity",
      labelKey: "form.work.quantity",
      type: "number",
      required: true,
      placeholder: "0",
    },
    { key: "price", labelKey: "form.work.price", type: "number", required: true, placeholder: "0" },
  ],
};
