import type { CurrencyCode } from "@/lib/types";
import { currencyInfo } from "@/lib/currency";

const numberFormatters = new Map<string, Intl.NumberFormat>();

function getNumberFormatter(locale: string): Intl.NumberFormat {
  let f = numberFormatters.get(locale);
  if (!f) {
    f = new Intl.NumberFormat(locale, { maximumFractionDigits: 2 });
    numberFormatters.set(locale, f);
  }
  return f;
}

export function formatNumber(value: number): string {
  return getNumberFormatter("ru-RU").format(value);
}

export function formatMoney(value: number, currency: CurrencyCode | string = "₽"): string {
  const info = currencyInfo(currency);
  const num = getNumberFormatter(info.locale).format(Math.round(value));
  if (info.code === "BYN") return `${num} BYN`;
  if (info.code === "$") return `$${num}`;
  if (info.code === "€") return `${num} €`;
  return `${num} ₽`;
}

export function parseAmount(raw: string): number | null {
  const normalized = raw.replace(/\s/g, "").replace(",", ".");
  if (!/^\d+(\.\d+)?$/.test(normalized)) return null;
  return Number(normalized);
}
