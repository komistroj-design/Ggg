import { useEffect, useState, type FormEvent } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { HardHat, Loader2, Lock } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { translations } from "@/lib/translations";

export const Route = createFileRoute("/reset-password")({
  head: () => ({
    meta: [
      { title: "Новый пароль — КомиСтрой Учет" },
      { name: "description", content: "Задайте новый пароль для входа в КомиСтрой Учет." },
      { property: "og:title", content: "Новый пароль — КомиСтрой Учет" },
      { property: "og:description", content: "Задайте новый пароль для входа в КомиСтрой Учет." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: ResetPasswordPage,
});

function ResetPasswordPage() {
  const navigate = useNavigate();
  const [lang, setLang] = useState<"ru" | "en">("ru");
  const t = translations[lang].auth;
  const [ready, setReady] = useState<"checking" | "ok" | "invalid">("checking");
  const [password, setPassword] = useState("");
  const [pending, setPending] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [done, setDone] = useState(false);

  useEffect(() => {
    if (navigator.language.startsWith("en")) setLang("en");
    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      if (event === "PASSWORD_RECOVERY" || session) setReady("ok");
    });
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) setReady("ok");
    });
    const timer = setTimeout(
      () => setReady((prev) => (prev === "checking" ? "invalid" : prev)),
      4000,
    );
    return () => {
      sub.subscription.unsubscribe();
      clearTimeout(timer);
    };
  }, []);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    if (password.length < 6) {
      setError(t.errorPassword);
      return;
    }
    setPending(true);
    const { error: updateError } = await supabase.auth.updateUser({ password });
    setPending(false);
    if (updateError) {
      setError(t.errorGeneric);
      return;
    }
    setDone(true);
    setTimeout(() => void navigate({ to: "/" }), 1200);
  };

  return (
    <div className="min-h-dvh bg-background text-foreground antialiased">
      <div className="mx-auto flex min-h-dvh w-full max-w-md flex-col items-center justify-center px-6 py-10">
        <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg shadow-primary/20">
          <HardHat className="h-8 w-8" />
        </span>
        <h1 className="mt-6 text-2xl font-bold tracking-tight">{t.resetTitle}</h1>
        <p className="mt-2 max-w-xs text-center text-sm leading-relaxed text-muted-foreground">
          {t.resetSubtitle}
        </p>

        {ready === "checking" && <Loader2 className="mt-10 h-6 w-6 animate-spin text-primary" />}

        {ready === "invalid" && (
          <div className="mt-10 flex w-full flex-col gap-4">
            <p className="rounded-xl bg-red-500/10 px-4 py-3 text-sm text-red-700 dark:text-red-300">
              {t.resetInvalid}
            </p>
            <Link
              to="/"
              className="text-center text-sm text-muted-foreground transition hover:text-foreground"
            >
              {t.toLogin}
            </Link>
          </div>
        )}

        {ready === "ok" && (
          <form onSubmit={handleSubmit} className="mt-10 flex w-full flex-col gap-4">
            <label className="flex flex-col gap-1.5">
              <span className="text-sm text-muted-foreground">{t.password}</span>
              <div className="relative">
                <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
                <input
                  type="password"
                  autoComplete="new-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  disabled={pending || done}
                  placeholder="••••••"
                  className="h-12 w-full rounded-xl border border-border bg-card pl-11 pr-4 text-base text-foreground placeholder:text-faint transition focus:border-primary/60 focus:outline-none focus:ring-2 focus:ring-primary/20 disabled:opacity-60"
                />
              </div>
              <span className="text-xs text-faint">{t.passwordHint}</span>
            </label>
            {error && (
              <p className="rounded-xl bg-red-500/10 px-4 py-3 text-sm text-red-700 dark:text-red-300">
                {error}
              </p>
            )}
            {done && (
              <p className="rounded-xl bg-emerald-500/10 px-4 py-3 text-sm text-emerald-700 dark:text-emerald-300">
                {t.resetDone}
              </p>
            )}
            <button
              type="submit"
              disabled={pending || done}
              className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary font-semibold text-primary-foreground transition hover:bg-primary/90 active:scale-[0.98] disabled:opacity-70"
            >
              {pending && <Loader2 className="h-4 w-4 animate-spin" />}
              {t.resetBtn}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
