import { createFileRoute } from "@tanstack/react-router";
import { AuthProvider } from "@/hooks/useAuth";
import KomistrojApp from "@/components/KomistrojApp";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "КомиСтрой Учет — объекты, материалы и работы" },
      {
        name: "description",
        content:
          "Ведите учет строительных объектов: договор, оплаты, материалы, работы и баланс в одном месте.",
      },
      { property: "og:title", content: "КомиСтрой Учет — объекты, материалы и работы" },
      {
        property: "og:description",
        content:
          "Ведите учет строительных объектов: договор, оплаты, материалы, работы и баланс в одном месте.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

function Index() {
  return (
    <AuthProvider>
      <KomistrojApp />
    </AuthProvider>
  );
}
