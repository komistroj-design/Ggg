import { describe, expect, it } from "vitest";
import { entryInputFrom, objectInputFrom } from "@/lib/database";
import { applyTheme, resolveIsDark } from "@/hooks/useTheme";

describe("saving records", () => {
  it("stores empty number fields of an object as 0", () => {
    const input = objectInputFrom({
      name: "Держинского 15",
      contract_sum: "",
      paid_by_client: "",
      worker_payouts: "",
      status: "В работе",
    });
    expect(input.contract_sum).toBe(0);
    expect(input.paid_by_client).toBe(0);
    expect(input.worker_payouts).toBe(0);
  });

  it("stores empty quantity and price of a material or work as 0", () => {
    const input = entryInputFrom({ name: "Цемент", quantity: "", price: "" });
    expect(input.quantity).toBe(0);
    expect(input.price).toBe(0);
  });
});

describe("theme picker", () => {
  it("Light removes the dark class from the page", () => {
    const root = document.documentElement;
    root.classList.add("dark");
    applyTheme(resolveIsDark("light", true), root);
    expect(root.classList.contains("dark")).toBe(false);
  });

  it("Dark adds the dark class to the page", () => {
    const root = document.documentElement;
    root.classList.remove("dark");
    applyTheme(resolveIsDark("dark", false), root);
    expect(root.classList.contains("dark")).toBe(true);
  });
});
