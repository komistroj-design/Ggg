import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { Bot, Loader2, Send, X } from "lucide-react";
import { useI18n } from "@/lib/i18n";
import { formatMoney } from "@/lib/format";
import { buildContext, streamReply } from "@/lib/aiForeman";
import type { Project, ProjectEntry } from "@/lib/types";

type AiChatSheetProps = {
  project: Project;
  materials: ProjectEntry[];
  works: ProjectEntry[];
  onClose: () => void;
};

type ChatRole = "user" | "assistant";

type ChatMessage = {
  id: number;
  role: ChatRole;
  content: string;
  failed?: boolean;
};

export default function AiChatSheet({ project, materials, works, onClose }: AiChatSheetProps) {
  const { t, lang } = useI18n();
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [pending, setPending] = useState(false);
  const nextId = useRef(1);
  const scrollRef = useRef<HTMLDivElement>(null);
  const abortRef = useRef<AbortController | null>(null);

  const quickPrompts = [t("ai.quick1"), t("ai.quick2"), t("ai.quick3")];

  const context = useMemo(
    () => buildContext(project, materials, works),
    [project, materials, works],
  );

  useEffect(() => {
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [onClose]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, pending]);

  const send = async (text: string) => {
    const content = text.trim();
    if (!content || pending) return;

    const userMessage: ChatMessage = { id: nextId.current++, role: "user", content };
    const history = [...messages, userMessage];
    setMessages(history);
    setInput("");
    setPending(true);

    const assistantId = nextId.current++;
    setMessages((prev) => [...prev, { id: assistantId, role: "assistant", content: "" }]);

    const controller = new AbortController();
    abortRef.current = controller;

    try {
      await streamReply(
        context,
        history.map(({ role, content: text }) => ({ role, content: text })),
        lang,
        (chunk) => {
          setMessages((prev) =>
            prev.map((m) => (m.id === assistantId ? { ...m, content: m.content + chunk } : m)),
          );
        },
        controller.signal,
      );
    } catch (err) {
      const isAbort = err instanceof DOMException && err.name === "AbortError";
      if (!isAbort) {
        setMessages((prev) =>
          prev.map((m) =>
            m.id === assistantId ? { ...m, content: t("ai.error"), failed: true } : m,
          ),
        );
      }
    } finally {
      setPending(false);
      abortRef.current = null;
    }
  };

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    void send(input);
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-center bg-background animate-[fade-in_0.2s_ease-out]">
      <div className="flex h-dvh w-full max-w-md flex-col">
        <header className="flex items-center gap-3 border-b border-border px-4 pb-4 pt-[calc(1rem+env(safe-area-inset-top))]">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <Bot className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <h2 className="text-base font-semibold text-foreground">{t("ai.title")}</h2>
            <p className="truncate text-xs text-subtle">
              {project.name} · {formatMoney(project.balance, project.currency)}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="flex h-10 w-10 items-center justify-center rounded-full text-muted-foreground transition hover:bg-secondary hover:text-foreground"
            aria-label={t("nav.back")}
          >
            <X className="h-5 w-5" />
          </button>
        </header>

        <div ref={scrollRef} className="flex-1 space-y-3 overflow-y-auto px-4 py-4">
          {messages.length === 0 && (
            <div className="space-y-4 pt-4">
              <p className="text-sm leading-relaxed text-muted-foreground">
                {t("ai.intro", { name: project.name })}
              </p>
              <div className="flex flex-col gap-2">
                {quickPrompts.map((prompt) => (
                  <button
                    key={prompt}
                    type="button"
                    onClick={() => void send(prompt)}
                    className="rounded-2xl border border-border bg-card/60 px-4 py-3 text-left text-sm text-foreground transition hover:border-primary/50 hover:text-amber-700 dark:hover:text-amber-200 active:scale-[0.98]"
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            </div>
          )}

          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex animate-[fade-in_0.25s_ease-out] ${
                message.role === "user" ? "justify-end" : "justify-start"
              }`}
            >
              <div
                className={`max-w-[85%] whitespace-pre-wrap rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                  message.role === "user"
                    ? "rounded-br-md bg-primary text-primary-foreground"
                    : message.failed
                      ? "rounded-bl-md bg-red-500/10 text-red-700 dark:text-red-300 ring-1 ring-inset ring-red-500/30"
                      : "rounded-bl-md bg-secondary text-foreground"
                }`}
              >
                {message.content}
              </div>
            </div>
          ))}

          {pending && messages.length > 0 && messages[messages.length - 1]?.content === "" && (
            <div className="flex justify-start">
              <div className="flex items-center gap-2 rounded-2xl rounded-bl-md bg-secondary px-4 py-3 text-sm text-muted-foreground">
                <Loader2 className="h-4 w-4 animate-spin" />
                {t("ai.thinking")}
              </div>
            </div>
          )}
        </div>

        <form
          onSubmit={handleSubmit}
          className="flex items-center gap-2 border-t border-border px-4 pt-3 pb-[calc(0.75rem+env(safe-area-inset-bottom))]"
        >
          <input
            type="text"
            value={input}
            onChange={(event) => setInput(event.target.value)}
            placeholder={t("ai.placeholder")}
            disabled={pending}
            maxLength={4000}
            className="h-12 min-w-0 flex-1 rounded-xl border border-border bg-card px-4 text-base text-foreground placeholder:text-faint transition focus:border-primary/60 focus:outline-none focus:ring-2 focus:ring-primary/20 disabled:opacity-60"
          />
          <button
            type="submit"
            disabled={pending || input.trim() === ""}
            className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground transition hover:bg-primary/90 active:scale-95 disabled:opacity-40"
            aria-label={t("ai.send")}
          >
            <Send className="h-5 w-5" />
          </button>
        </form>
      </div>
    </div>
  );
}
