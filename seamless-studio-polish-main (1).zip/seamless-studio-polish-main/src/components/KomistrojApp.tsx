import { useMemo, useState } from "react";
import { HardHat, Loader2, RefreshCw, AlertTriangle, Settings as SettingsIcon } from "lucide-react";
import { useSiteData } from "@/hooks/useSiteData";
import { useAuth } from "@/hooks/useAuth";
import { useTheme } from "@/hooks/useTheme";
import { I18nProvider, useI18n } from "@/lib/i18n";
import { objectInputFrom } from "@/lib/database";
import { toProjects } from "@/lib/projects";
import { OBJECT_FORM } from "@/lib/recordConfig";
import type { FormValues } from "@/lib/types";
import ProjectList from "@/components/ProjectList";
import ProjectDetail from "@/components/ProjectDetail";
import AddRecordSheet from "@/components/AddRecordSheet";
import FloatingAddButton from "@/components/FloatingAddButton";
import LoginScreen from "@/components/LoginScreen";
import SettingsScreen from "@/components/SettingsScreen";

export default function App() {
  const { session, loading, settings, setSettings } = useAuth();

  const lang = settings?.language ?? "ru";
  const theme = settings?.theme ?? null;
  useTheme(theme);

  const setLang = (next: typeof lang) => {
    if (settings) void setSettings({ ...settings, language: next });
  };

  if (loading) {
    return (
      <div className="flex min-h-dvh items-center justify-center bg-background">
        <Loader2 className="h-8 w-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!session) {
    return (
      <I18nProvider lang={lang} setLang={setLang}>
        <LoginScreen />
      </I18nProvider>
    );
  }

  return (
    <I18nProvider lang={lang} setLang={setLang}>
      <AppContent />
    </I18nProvider>
  );
}

function AppContent() {
  const { t } = useI18n();
  const { session } = useAuth();
  const enabled = Boolean(session);
  const {
    state,
    reload,
    addObject,
    editObject,
    removeObject,
    addEntry,
    setMaterialStatus,
    setWorkPaid,
  } = useSiteData(enabled);
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [objectFormOpen, setObjectFormOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);

  const projects = useMemo(() => (state.status === "ready" ? toProjects(state.data) : []), [state]);
  const selectedProject = projects.find((project) => project.id === selectedId) ?? null;

  return (
    <div className="min-h-dvh bg-background text-foreground antialiased">
      <div className="mx-auto flex min-h-dvh w-full max-w-md flex-col">
        <header className="sticky top-0 z-30 border-b border-border bg-background/80 px-5 pb-4 pt-[calc(1rem+env(safe-area-inset-top))] backdrop-blur-xl">
          <div className="flex items-center gap-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary text-primary-foreground">
              <HardHat className="h-5 w-5" />
            </span>
            <div className="min-w-0 flex-1">
              <p className="text-base font-bold leading-tight tracking-tight">{t("app.name")}</p>
              <p className="text-xs leading-tight text-subtle">{t("app.tagline")}</p>
            </div>
            <button
              type="button"
              onClick={() => setSettingsOpen(true)}
              className="flex h-9 w-9 items-center justify-center rounded-xl text-muted-foreground transition hover:bg-secondary hover:text-foreground"
              aria-label={t("nav.settings")}
            >
              <SettingsIcon className="h-5 w-5" />
            </button>
          </div>
        </header>

        <main className="flex-1 px-5 pb-8 pt-5">
          {settingsOpen ? (
            <SettingsScreen onBack={() => setSettingsOpen(false)} />
          ) : state.status === "loading" ? (
            <LoadingState />
          ) : state.status === "error" ? (
            <ErrorState message={state.message} onRetry={() => void reload()} />
          ) : !selectedProject ? (
            <ProjectList projects={projects} onSelect={setSelectedId} />
          ) : (
            <ProjectDetail
              key={selectedProject.id}
              project={selectedProject}
              data={state.data}
              onBack={() => setSelectedId(null)}
              onAddEntry={addEntry}
              onEditObject={editObject}
              onDeleteObject={removeObject}
              onSetMaterialStatus={setMaterialStatus}
              onSetWorkPaid={setWorkPaid}
            />
          )}
        </main>
      </div>

      {!settingsOpen && state.status === "ready" && !selectedProject && (
        <>
          <FloatingAddButton label={t("add.object")} onClick={() => setObjectFormOpen(true)} />
          <AddRecordSheet
            open={objectFormOpen}
            config={OBJECT_FORM}
            onClose={() => setObjectFormOpen(false)}
            onSubmit={(values: FormValues) => addObject(objectInputFrom(values))}
          />
        </>
      )}
    </div>
  );
}

function LoadingState() {
  const { t } = useI18n();
  return (
    <div className="flex flex-col gap-3">
      <div className="flex items-center gap-2 px-1 text-sm text-subtle">
        <Loader2 className="h-4 w-4 animate-spin" />
        {t("loading")}
      </div>
      {[0, 1, 2].map((item) => (
        <div
          key={item}
          className="h-36 animate-pulse rounded-2xl border border-border bg-card/60"
        />
      ))}
    </div>
  );
}

function ErrorState({ message, onRetry }: { message: string; onRetry: () => void }) {
  const { t } = useI18n();
  return (
    <div className="flex flex-col items-center gap-4 rounded-2xl border border-red-500/30 bg-red-500/5 px-6 py-10 text-center">
      <AlertTriangle className="h-8 w-8 text-red-600 dark:text-red-400" />
      <p className="text-sm leading-relaxed text-red-700 dark:text-red-200">{message}</p>
      <button
        type="button"
        onClick={onRetry}
        className="flex h-10 items-center gap-2 rounded-xl bg-secondary px-4 text-sm font-medium text-foreground transition hover:bg-border-strong active:scale-95"
      >
        <RefreshCw className="h-4 w-4" />
        {t("errors.retry")}
      </button>
    </div>
  );
}
