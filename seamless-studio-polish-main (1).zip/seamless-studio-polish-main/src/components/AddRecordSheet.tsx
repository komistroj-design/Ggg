import { useState, type FormEvent } from "react";
import { X, Loader2 } from "lucide-react";
import { parseAmount } from "@/lib/format";
import { useI18n } from "@/lib/i18n";
import type { FormConfig } from "@/lib/recordConfig";
import type { FormValues } from "@/lib/types";

type AddRecordSheetProps = {
  open: boolean;
  config: FormConfig;
  initialValues?: FormValues | undefined;
  onClose: () => void;
  onSubmit: (values: FormValues) => Promise<void>;
};

function toDraftValue(
  field: FormConfig["fields"][number],
  initial?: FormValues[keyof FormValues],
): string {
  if (initial === undefined || initial === null) return field.defaultValue ?? "";
  if (field.type === "boolean") return initial ? "true" : "false";
  return String(initial);
}

function initialDraft(config: FormConfig, initial?: FormValues): Record<string, string> {
  return Object.fromEntries(
    config.fields.map((field) => [field.key, toDraftValue(field, initial?.[field.key])]),
  );
}

export default function AddRecordSheet({
  open,
  config,
  initialValues,
  onClose,
  onSubmit,
}: AddRecordSheetProps) {
  if (!open) return null;
  return (
    <RecordForm
      config={config}
      initialValues={initialValues}
      onClose={onClose}
      onSubmit={onSubmit}
    />
  );
}

function RecordForm({
  config,
  initialValues,
  onClose,
  onSubmit,
}: Omit<AddRecordSheetProps, "open">) {
  const { t } = useI18n();
  const [draft, setDraft] = useState(() => initialDraft(config, initialValues));
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const close = () => {
    if (!saving) onClose();
  };

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const values: FormValues = {};

    for (const field of config.fields) {
      if (field.type === "boolean") {
        values[field.key] = draft[field.key] === "true";
        continue;
      }
      const raw = (draft[field.key] ?? "").trim();
      if (field.required && raw === "") {
        setError(t("form.fillField", { field: t(field.labelKey) }));
        return;
      }
      if (field.type === "number") {
        if (raw === "") {
          values[field.key] = 0;
          continue;
        }
        const amount = parseAmount(raw);
        if (amount === null) {
          setError(t("form.mustBeNumber", { field: t(field.labelKey) }));
          return;
        }
        values[field.key] = amount;
      } else if (raw !== "") {
        values[field.key] = raw;
      } else {
        values[field.key] = "";
      }
    }

    setSaving(true);
    setError(null);
    try {
      await onSubmit(values);
      onClose();
    } catch (err) {
      setError(err instanceof Error ? err.message : t("form.saveError"));
    } finally {
      setSaving(false);
    }
  };

  const inputClass =
    "h-12 w-full rounded-xl border border-border bg-background px-4 text-base text-foreground placeholder:text-faint transition focus:border-primary/60 focus:outline-none focus:ring-2 focus:ring-primary/20 disabled:opacity-60";

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-overlay backdrop-blur-sm animate-[fade-in_0.2s_ease-out]">
      <button
        type="button"
        aria-label={t("nav.back")}
        className="absolute inset-0 cursor-default"
        onClick={close}
      />
      <form
        onSubmit={handleSubmit}
        className="relative max-h-[90dvh] w-full max-w-md overflow-y-auto rounded-t-3xl border border-border bg-card p-6 pb-[calc(1.5rem+env(safe-area-inset-bottom))] shadow-2xl animate-[sheet-up_0.3s_cubic-bezier(0.16,1,0.3,1)]"
      >
        <div className="mx-auto mb-5 h-1 w-10 rounded-full bg-border-strong" />
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-foreground">{t(config.titleKey)}</h3>
          <button
            type="button"
            onClick={close}
            disabled={saving}
            className="rounded-full p-2 text-muted-foreground transition hover:bg-secondary hover:text-foreground disabled:opacity-50"
            aria-label={t("nav.back")}
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="mt-5 flex flex-col gap-4">
          {config.fields.map((field) => {
            if (field.type === "boolean") {
              const checked = draft[field.key] === "true";
              return (
                <label key={field.key} className="flex items-center justify-between gap-3">
                  <span className="text-sm text-soft">{t(field.labelKey)}</span>
                  <button
                    type="button"
                    role="switch"
                    aria-checked={checked}
                    disabled={saving}
                    onClick={() =>
                      setDraft((prev) => ({ ...prev, [field.key]: checked ? "false" : "true" }))
                    }
                    className={`relative h-7 w-12 shrink-0 rounded-full transition disabled:opacity-60 ${
                      checked ? "bg-primary" : "bg-border-strong"
                    }`}
                  >
                    <span
                      className={`absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-all ${
                        checked ? "left-6" : "left-1"
                      }`}
                    />
                  </button>
                </label>
              );
            }

            return (
              <label key={field.key} className="flex flex-col gap-1.5">
                <span className="text-sm text-muted-foreground">
                  {t(field.labelKey)}
                  {field.required && <span className="text-primary"> *</span>}
                </span>
                {field.type === "select" ? (
                  <select
                    value={draft[field.key] ?? ""}
                    disabled={saving}
                    onChange={(event) =>
                      setDraft((prev) => ({ ...prev, [field.key]: event.target.value }))
                    }
                    className={inputClass}
                  >
                    {(field.options ?? []).map((option) => (
                      <option key={option} value={option}>
                        {option}
                      </option>
                    ))}
                  </select>
                ) : (
                  <input
                    type="text"
                    inputMode={field.type === "number" ? "decimal" : "text"}
                    placeholder={field.placeholder}
                    value={draft[field.key] ?? ""}
                    disabled={saving}
                    onChange={(event) =>
                      setDraft((prev) => ({ ...prev, [field.key]: event.target.value }))
                    }
                    className={inputClass}
                  />
                )}
              </label>
            );
          })}
        </div>

        {error && (
          <p
            role="alert"
            className="mt-4 rounded-xl bg-red-500/10 px-4 py-3 text-sm text-red-700 dark:text-red-300"
          >
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={saving}
          className="mt-6 flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary font-semibold text-primary-foreground transition hover:bg-primary/90 active:scale-[0.98] disabled:opacity-70"
        >
          {saving && <Loader2 className="h-4 w-4 animate-spin" />}
          {saving ? t("form.saving") : t("form.save")}
        </button>
      </form>
    </div>
  );
}
