import { Check, PackageCheck, CircleDot, Loader2 } from "lucide-react";
import { formatMoney, formatNumber } from "@/lib/format";
import { useI18n, localizeStatus } from "@/lib/i18n";
import { STATUS_DELIVERED, STATUS_PLANNED } from "@/lib/recordConfig";
import type { EntryKind, ProjectEntry } from "@/lib/types";

type EntryListProps = {
  kind: EntryKind;
  entries: ProjectEntry[];
  currency: string;
  emptyText: string;
  onToggleMaterialStatus?: ((id: string, status: string) => void) | undefined;
  onToggleWorkPaid?: ((id: string, paid: boolean) => void) | undefined;
};

export default function EntryList({
  kind,
  entries,
  currency,
  emptyText,
  onToggleMaterialStatus,
  onToggleWorkPaid,
}: EntryListProps) {
  const { t, lang } = useI18n();

  if (entries.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-border px-6 py-10 text-center text-sm text-muted-foreground">
        {emptyText}
      </div>
    );
  }

  const grandTotal = entries.reduce((sum, entry) => sum + entry.total, 0);

  return (
    <div className="flex flex-col gap-2">
      {entries.map((entry) => (
        <EntryCard
          key={entry.id}
          kind={kind}
          entry={entry}
          currency={currency}
          t={t}
          lang={lang}
          onToggleMaterialStatus={onToggleMaterialStatus}
          onToggleWorkPaid={onToggleWorkPaid}
        />
      ))}
      <div className="mt-2 flex items-center justify-between px-1 text-sm">
        <span className="text-muted-foreground">{t("detail.total")}</span>
        <span className="font-semibold tabular-nums text-amber-700 dark:text-amber-300">
          {formatMoney(grandTotal, currency)}
        </span>
      </div>
    </div>
  );
}

type EntryCardProps = {
  kind: EntryKind;
  entry: ProjectEntry;
  currency: string;
  t: (key: string, vars?: Record<string, string | number>) => string;
  lang: "ru" | "en";
  onToggleMaterialStatus?: ((id: string, status: string) => void) | undefined;
  onToggleWorkPaid?: ((id: string, paid: boolean) => void) | undefined;
};

function EntryCard({
  kind,
  entry,
  currency,
  t,
  lang,
  onToggleMaterialStatus,
  onToggleWorkPaid,
}: EntryCardProps) {
  const isDelivered = entry.status === STATUS_DELIVERED;
  const isPaid = Boolean(entry.paid);

  const toggleMaterial = () => {
    if (!onToggleMaterialStatus) return;
    const next = isDelivered ? STATUS_PLANNED : STATUS_DELIVERED;
    onToggleMaterialStatus(entry.id, next);
  };

  const toggleWork = () => {
    if (!onToggleWorkPaid) return;
    onToggleWorkPaid(entry.id, !isPaid);
  };

  return (
    <div className="flex flex-col gap-2 rounded-2xl border border-border bg-card/60 px-4 py-3">
      <div className="flex items-start justify-between gap-3">
        <div className="min-w-0">
          <p
            className={`truncate text-sm font-medium ${isPaid ? "text-subtle line-through" : "text-foreground"}`}
          >
            {entry.name || "—"}
          </p>
          <p className="mt-0.5 text-xs text-subtle">
            {formatNumber(entry.quantity)} {entry.unit} × {formatMoney(entry.price, currency)}
          </p>
        </div>
        <p className="shrink-0 text-sm font-semibold tabular-nums text-foreground">
          {formatMoney(entry.total, currency)}
        </p>
      </div>

      {kind === "materials" && onToggleMaterialStatus && (
        <button
          type="button"
          onClick={toggleMaterial}
          className={`flex items-center gap-1.5 self-start rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset transition active:scale-95 ${
            isDelivered
              ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 ring-emerald-500/30"
              : "bg-secondary text-muted-foreground ring-border-strong hover:text-foreground"
          }`}
        >
          {isDelivered ? (
            <PackageCheck className="h-3.5 w-3.5" />
          ) : (
            <CircleDot className="h-3.5 w-3.5" />
          )}
          {localizeStatus(entry.status ?? STATUS_PLANNED, lang) ||
            t("entry.materialStatus.planned")}
        </button>
      )}

      {kind === "works" && onToggleWorkPaid && (
        <button
          type="button"
          onClick={toggleWork}
          className={`flex items-center gap-1.5 self-start rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset transition active:scale-95 ${
            isPaid
              ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 ring-emerald-500/30"
              : "bg-primary/10 text-amber-700 dark:text-amber-200 ring-primary/30 hover:bg-primary/20"
          }`}
        >
          {isPaid ? (
            <Check className="h-3.5 w-3.5" />
          ) : (
            <Loader2 className="h-3.5 w-3.5 opacity-0" />
          )}
          {isPaid ? t("entry.paid") : t("entry.markPaid")}
        </button>
      )}
    </div>
  );
}
