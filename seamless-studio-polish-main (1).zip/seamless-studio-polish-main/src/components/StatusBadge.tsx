import { STATUS_DONE, STATUS_PAUSED } from "@/lib/recordConfig";
import { useLocalizedStatus } from "@/lib/i18n";

type StatusBadgeProps = {
  status: string;
};

export default function StatusBadge({ status }: StatusBadgeProps) {
  const localize = useLocalizedStatus();
  const isDone = status === STATUS_DONE;
  const isPaused = status === STATUS_PAUSED;
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ring-1 ring-inset ${
        isDone
          ? "bg-emerald-500/10 text-emerald-700 dark:text-emerald-300 ring-emerald-500/30"
          : isPaused
            ? "bg-sky-500/10 text-sky-700 dark:text-sky-300 ring-sky-500/30"
            : "bg-primary/10 text-amber-700 dark:text-amber-200 ring-primary/30"
      }`}
    >
      {localize(status)}
    </span>
  );
}
