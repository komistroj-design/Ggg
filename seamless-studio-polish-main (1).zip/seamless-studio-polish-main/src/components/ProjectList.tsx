import { CheckCircle2, PauseCircle } from "lucide-react";
import type { Project } from "@/lib/types";
import { formatMoney } from "@/lib/format";
import { useI18n } from "@/lib/i18n";
import StatusBadge from "@/components/StatusBadge";

type ProjectListProps = {
  projects: Project[];
  onSelect: (id: string) => void;
};

export default function ProjectList({ projects, onSelect }: ProjectListProps) {
  const { t } = useI18n();

  if (projects.length === 0) {
    return (
      <div className="rounded-2xl border border-dashed border-border px-6 py-12 text-center text-sm text-muted-foreground">
        {t("list.empty")}
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3">
      <p className="px-1 text-xs font-medium uppercase tracking-wider text-subtle">
        {t("list.count", { count: projects.length })}
      </p>
      {projects.map((project) => (
        <ProjectCard key={project.id} project={project} onSelect={onSelect} />
      ))}
    </div>
  );
}

function ProjectCard({ project, onSelect }: { project: Project; onSelect: (id: string) => void }) {
  const { t } = useI18n();
  const balanceTone = project.inDebt
    ? "text-red-600 dark:text-red-400"
    : project.isDone
      ? "text-emerald-600 dark:text-emerald-400"
      : "text-foreground";

  const displayBalance =
    project.includesTax || project.includesVat ? project.netBalance : project.balance;
  const balanceLabel =
    project.includesTax || project.includesVat
      ? t("detail.netBalance")
      : project.inDebt
        ? t("list.debt")
        : t("list.balance");

  return (
    <button
      type="button"
      onClick={() => onSelect(project.id)}
      className="group w-full rounded-2xl border border-border bg-card/70 p-4 text-left transition duration-200 hover:border-border-strong hover:bg-card active:scale-[0.98]"
    >
      <div className="flex items-start justify-between gap-3">
        <h2 className="text-base font-semibold leading-snug text-foreground">{project.name}</h2>
        <StatusBadge status={project.status} />
      </div>
      {project.description && (
        <p className="mt-1.5 line-clamp-1 text-sm text-muted-foreground">{project.description}</p>
      )}

      {project.isPaused && project.pauseReason && (
        <p className="mt-2 flex items-center gap-1.5 rounded-lg bg-sky-500/5 px-3 py-2 text-xs text-sky-700 dark:text-sky-300">
          <PauseCircle className="h-3.5 w-3.5 shrink-0" />
          <span className="line-clamp-2">{project.pauseReason}</span>
        </p>
      )}

      <div className="mt-4 flex items-end justify-between gap-3">
        <div>
          <p className="text-xs text-subtle">{t("list.contractSum")}</p>
          <p className="mt-0.5 text-sm font-medium text-soft">
            {formatMoney(project.contractSum, project.currency)}
          </p>
        </div>
        <div className="text-right">
          <p className="text-xs text-subtle">{balanceLabel}</p>
          <div className="mt-0.5 flex items-center justify-end gap-1.5">
            <p className={`text-lg font-bold tabular-nums ${balanceTone}`}>
              {formatMoney(displayBalance, project.currency)}
            </p>
            {project.isDone && !project.inDebt && (
              <CheckCircle2
                className="h-5 w-5 shrink-0 text-emerald-600 dark:text-emerald-400"
                aria-label={t("status.done")}
              />
            )}
          </div>
        </div>
      </div>
    </button>
  );
}
