import { useMemo, useState } from "react";
import {
  ChevronLeft,
  Bot,
  Package,
  Hammer,
  Pencil,
  Trash2,
  Share2,
  AlertTriangle,
  X,
  ClipboardCopy,
} from "lucide-react";
import {
  MATERIAL_FORM,
  OBJECT_FORM,
  WORK_FORM,
  STATUS_DONE,
  STATUS_IN_PROGRESS,
  STATUS_PAUSED,
} from "@/lib/recordConfig";
import { formatMoney } from "@/lib/format";
import { toEntries } from "@/lib/projects";
import { entryInputFrom, objectInputFrom, type EntryInput, type ObjectInput } from "@/lib/database";
import { useI18n, localizeStatus } from "@/lib/i18n";
import type { EntryKind, FormValues, Project, SiteData } from "@/lib/types";
import StatusBadge from "@/components/StatusBadge";
import EntryList from "@/components/EntryList";
import AddRecordSheet from "@/components/AddRecordSheet";
import FloatingAddButton from "@/components/FloatingAddButton";
import AiChatSheet from "@/components/AiChatSheet";

type ProjectDetailProps = {
  project: Project;
  data: SiteData;
  onBack: () => void;
  onAddEntry: (kind: EntryKind, objectId: string, values: EntryInput) => Promise<void>;
  onEditObject: (id: string, values: ObjectInput) => Promise<void>;
  onDeleteObject: (id: string) => Promise<void>;
  onSetMaterialStatus: (id: string, status: string) => Promise<void>;
  onSetWorkPaid: (id: string, paid: boolean) => Promise<void>;
};

export default function ProjectDetail({
  project,
  data,
  onBack,
  onAddEntry,
  onEditObject,
  onDeleteObject,
  onSetMaterialStatus,
  onSetWorkPaid,
}: ProjectDetailProps) {
  const { t, lang } = useI18n();
  const [tab, setTab] = useState<EntryKind>("materials");
  const [addOpen, setAddOpen] = useState(false);
  const [chatOpen, setChatOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [shareToast, setShareToast] = useState(false);
  const [pausePromptOpen, setPausePromptOpen] = useState(false);
  const [statusSaving, setStatusSaving] = useState(false);

  const materials = useMemo(
    () => toEntries(data.materials, project.id),
    [data.materials, project.id],
  );
  const works = useMemo(() => toEntries(data.works, project.id), [data.works, project.id]);
  const entries = tab === "materials" ? materials : works;

  const balanceTone = project.inDebt
    ? "text-red-600 dark:text-red-400"
    : project.isDone
      ? "text-emerald-600 dark:text-emerald-400"
      : "text-foreground";

  const submitEntry = (values: FormValues) => onAddEntry(tab, project.id, entryInputFrom(values));

  const handleEditSubmit = async (values: FormValues) => {
    await onEditObject(project.id, objectInputFrom(values));
  };

  const handleStatusChange = async (newStatus: string) => {
    if (newStatus === project.status) return;
    if (newStatus === STATUS_PAUSED) {
      setPausePromptOpen(true);
      return;
    }
    setStatusSaving(true);
    try {
      await onEditObject(
        project.id,
        objectInputFrom({
          ...objectInitialValues(project),
          status: newStatus,
          pause_reason: "",
        }),
      );
    } finally {
      setStatusSaving(false);
    }
  };

  const handlePauseConfirm = async (reason: string) => {
    setStatusSaving(true);
    try {
      await onEditObject(
        project.id,
        objectInputFrom({
          ...objectInitialValues(project),
          status: STATUS_PAUSED,
          pause_reason: reason,
        }),
      );
      setPausePromptOpen(false);
    } finally {
      setStatusSaving(false);
    }
  };

  const handleDelete = async () => {
    await onDeleteObject(project.id);
    onBack();
  };

  const handleShare = async () => {
    const lines = [
      t("shareSummary.title", { name: project.name }),
      t("shareSummary.status", { status: localizeStatus(project.status, lang) }),
      t("shareSummary.contract", { sum: formatMoney(project.contractSum, project.currency) }),
      t("shareSummary.paid", { sum: formatMoney(project.paidByClient, project.currency) }),
      t("shareSummary.materials", {
        sum: formatMoney(project.materialsTotal, project.currency),
        count: materials.length,
      }),
      t("shareSummary.works", {
        sum: formatMoney(project.worksTotal, project.currency),
        count: works.length,
      }),
      t("shareSummary.balance", { sum: formatMoney(project.balance, project.currency) }),
    ];
    if (project.includesTax || project.includesVat) {
      lines.push(t("shareSummary.net", { sum: formatMoney(project.netBalance, project.currency) }));
    }
    const text = lines.join("\n");
    try {
      await navigator.clipboard.writeText(text);
      setShareToast(true);
      setTimeout(() => setShareToast(false), 2500);
    } catch {
      // ignore
    }
  };

  const tabLabel = (key: EntryKind) =>
    key === "materials" ? t("detail.materials") : t("detail.works");

  return (
    <div className="flex flex-col gap-6 pb-24 animate-[fade-in_0.3s_ease-out]">
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={onBack}
          className="-ml-2 flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-soft transition hover:bg-secondary hover:text-foreground"
          aria-label={t("nav.back")}
        >
          <ChevronLeft className="h-6 w-6" />
        </button>
        <h2 className="min-w-0 flex-1 truncate text-lg font-semibold text-foreground">
          {project.name}
        </h2>
        <StatusBadge status={project.status} />
      </div>

      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={() => setEditOpen(true)}
          className="flex h-10 flex-1 items-center justify-center gap-2 rounded-xl border border-border bg-card/70 text-sm font-medium text-foreground transition hover:border-primary/40 hover:text-amber-700 dark:hover:text-amber-200 active:scale-[0.98]"
        >
          <Pencil className="h-4 w-4" />
          {t("detail.edit")}
        </button>
        <button
          type="button"
          onClick={handleShare}
          className="flex h-10 flex-1 items-center justify-center gap-2 rounded-xl border border-border bg-card/70 text-sm font-medium text-foreground transition hover:border-sky-400/40 hover:text-sky-700 dark:hover:text-sky-200 active:scale-[0.98]"
        >
          <Share2 className="h-4 w-4" />
          {t("detail.share")}
        </button>
        <button
          type="button"
          onClick={() => setDeleteOpen(true)}
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-border bg-card/70 text-muted-foreground transition hover:border-red-500/40 hover:text-red-600 dark:hover:text-red-400 active:scale-[0.98]"
          aria-label={t("detail.delete")}
        >
          <Trash2 className="h-4 w-4" />
        </button>
      </div>

      {shareToast && (
        <div className="fixed inset-x-0 top-20 z-50 mx-auto w-fit max-w-[90%] rounded-xl bg-emerald-500/90 px-4 py-2 text-sm font-medium text-white shadow-lg animate-[fade-in_0.2s_ease-out]">
          {t("detail.shared")}
        </div>
      )}

      <section className="rounded-3xl border border-border bg-card/70 p-5">
        {project.description && (
          <>
            <p className="text-xs font-medium uppercase tracking-wider text-subtle">
              {t("detail.scope")}
            </p>
            <p className="mt-1.5 text-sm leading-relaxed text-soft">{project.description}</p>
          </>
        )}

        <div className="mt-5 grid grid-cols-2 gap-4 border-t border-border pt-5">
          <div>
            <p className="text-xs text-subtle">{t("detail.contractSum")}</p>
            <p className="mt-1 text-base font-semibold tabular-nums text-foreground">
              {formatMoney(project.contractSum, project.currency)}
            </p>
            {project.includesVat && (
              <p className="mt-0.5 text-xs text-amber-700/80 dark:text-amber-300/80">
                {t("detail.vatIncluded")}
              </p>
            )}
          </div>
          <div>
            <p className="text-xs text-subtle">
              {project.includesTax || project.includesVat
                ? t("detail.netBalance")
                : project.inDebt
                  ? t("detail.debt")
                  : t("detail.balance")}
            </p>
            <p className={`mt-1 text-base font-bold tabular-nums ${balanceTone}`}>
              {formatMoney(
                project.includesTax || project.includesVat ? project.netBalance : project.balance,
                project.currency,
              )}
            </p>
          </div>
        </div>

        {project.includesVat && (
          <p className="mt-3 text-xs text-subtle">
            {t("detail.vatIncluded")}:{" "}
            <span className="tabular-nums text-soft">
              {formatMoney(project.vatAmount, project.currency)}
            </span>
          </p>
        )}
        {project.includesTax && (
          <p className="mt-1 text-xs text-subtle">
            {t("detail.tax")}:{" "}
            <span className="tabular-nums text-soft">
              {formatMoney(project.taxAmount, project.currency)}
            </span>
          </p>
        )}

        {project.isPaused && project.pauseReason && (
          <div className="mt-4 rounded-xl bg-sky-500/5 px-4 py-3">
            <p className="text-xs font-medium text-sky-700/80 dark:text-sky-300/80">
              {t("detail.pauseReason")}
            </p>
            <p className="mt-1 text-sm leading-relaxed text-sky-700 dark:text-sky-200">
              {project.pauseReason}
            </p>
          </div>
        )}
      </section>

      <div>
        <p className="mb-2 px-1 text-xs font-medium uppercase tracking-wider text-subtle">
          {t("detail.status")}
        </p>
        <div className="flex gap-1 rounded-2xl bg-card p-1">
          {[STATUS_IN_PROGRESS, STATUS_PAUSED, STATUS_DONE].map((status) => {
            const active = project.status === status;
            const tone = active
              ? status === STATUS_DONE
                ? "bg-emerald-500/15 text-emerald-700 dark:text-emerald-300"
                : status === STATUS_PAUSED
                  ? "bg-sky-500/15 text-sky-700 dark:text-sky-300"
                  : "bg-primary/15 text-amber-700 dark:text-amber-200"
              : "text-subtle hover:text-soft";
            return (
              <button
                key={status}
                type="button"
                disabled={statusSaving}
                onClick={() => void handleStatusChange(status)}
                className={`flex h-10 flex-1 items-center justify-center rounded-xl text-xs font-medium transition disabled:opacity-50 ${tone}`}
              >
                {localizeStatus(status, lang)}
              </button>
            );
          })}
        </div>
      </div>

      <button
        type="button"
        onClick={() => setChatOpen(true)}
        className="group flex h-16 w-full items-center justify-between rounded-2xl bg-primary px-5 text-left text-primary-foreground shadow-lg shadow-primary/10 transition hover:bg-primary/90 active:scale-[0.98]"
      >
        <span className="flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-primary-foreground/10">
            <Bot className="h-5 w-5" />
          </span>
          <span>
            <span className="block text-base font-semibold">{t("detail.aiChat")}</span>
            <span className="block text-xs text-primary-foreground/80">
              {t("detail.aiChatSub")}
            </span>
          </span>
        </span>
        <span className="text-xl transition group-hover:translate-x-1">&rarr;</span>
      </button>

      <div>
        <div className="grid grid-cols-2 gap-1 rounded-2xl bg-card p-1">
          {(["materials", "works"] as const).map((key) => {
            const active = tab === key;
            const Icon = key === "materials" ? Package : Hammer;
            const count = key === "materials" ? materials.length : works.length;
            return (
              <button
                key={key}
                type="button"
                onClick={() => setTab(key)}
                className={`flex h-10 items-center justify-center gap-2 rounded-xl text-sm font-medium transition ${
                  active ? "bg-secondary text-foreground shadow-sm" : "text-subtle hover:text-soft"
                }`}
              >
                <Icon className="h-4 w-4" />
                {tabLabel(key)}
                <span className="text-xs text-subtle">{count}</span>
              </button>
            );
          })}
        </div>

        <div className="mt-4">
          <EntryList
            kind={tab}
            entries={entries}
            currency={project.currency}
            emptyText={tab === "materials" ? t("detail.noMaterials") : t("detail.noWorks")}
            onToggleMaterialStatus={tab === "materials" ? onSetMaterialStatus : undefined}
            onToggleWorkPaid={tab === "works" ? onSetWorkPaid : undefined}
          />
        </div>
      </div>

      <FloatingAddButton
        label={tab === "materials" ? t("add.material") : t("add.work")}
        onClick={() => setAddOpen(true)}
      />

      <AddRecordSheet
        open={addOpen}
        config={tab === "materials" ? MATERIAL_FORM : WORK_FORM}
        onClose={() => setAddOpen(false)}
        onSubmit={submitEntry}
      />

      <AddRecordSheet
        open={editOpen}
        config={OBJECT_FORM_EDIT}
        initialValues={objectInitialValues(project)}
        onClose={() => setEditOpen(false)}
        onSubmit={handleEditSubmit}
      />

      {deleteOpen && (
        <DeleteDialog
          projectName={project.name}
          onCancel={() => setDeleteOpen(false)}
          onConfirm={handleDelete}
        />
      )}

      {pausePromptOpen && (
        <PausePromptDialog
          onCancel={() => setPausePromptOpen(false)}
          onConfirm={handlePauseConfirm}
          saving={statusSaving}
        />
      )}

      {chatOpen && (
        <AiChatSheet
          project={project}
          materials={materials}
          works={works}
          onClose={() => setChatOpen(false)}
        />
      )}
    </div>
  );
}

function PausePromptDialog({
  onCancel,
  onConfirm,
  saving,
}: {
  onCancel: () => void;
  onConfirm: (reason: string) => Promise<void>;
  saving: boolean;
}) {
  const { t } = useI18n();
  const [reason, setReason] = useState("");

  const submit = async () => {
    const trimmed = reason.trim();
    if (!trimmed) return;
    await onConfirm(trimmed);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-overlay px-6 backdrop-blur-sm animate-[fade-in_0.2s_ease-out]">
      <div className="w-full max-w-sm rounded-2xl border border-border bg-card p-6 shadow-2xl">
        <div className="flex items-start justify-between gap-3">
          <div>
            <h3 className="text-base font-semibold text-foreground">
              {t("detail.pausePromptTitle")}
            </h3>
            <p className="mt-1 text-sm text-muted-foreground">{t("detail.pausePrompt")}</p>
          </div>
          <button
            type="button"
            onClick={onCancel}
            disabled={saving}
            className="rounded-full p-1.5 text-subtle transition hover:bg-secondary hover:text-foreground disabled:opacity-50"
            aria-label={t("detail.cancel")}
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <textarea
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          disabled={saving}
          rows={3}
          maxLength={500}
          className="mt-4 w-full rounded-xl border border-border bg-background px-4 py-3 text-sm text-foreground placeholder:text-faint transition focus:border-primary/60 focus:outline-none focus:ring-2 focus:ring-primary/20 disabled:opacity-60"
          placeholder="..."
          autoFocus
        />
        <div className="mt-4 flex gap-3">
          <button
            type="button"
            onClick={onCancel}
            disabled={saving}
            className="h-11 flex-1 rounded-xl border border-border text-sm font-medium text-soft transition hover:bg-secondary disabled:opacity-50"
          >
            {t("detail.cancel")}
          </button>
          <button
            type="button"
            onClick={submit}
            disabled={saving || reason.trim() === ""}
            className="h-11 flex-1 rounded-xl bg-sky-500 text-sm font-semibold text-white transition hover:bg-sky-600 active:scale-[0.98] disabled:opacity-50"
          >
            {t("form.save")}
          </button>
        </div>
      </div>
    </div>
  );
}

const OBJECT_FORM_EDIT: typeof OBJECT_FORM = {
  ...OBJECT_FORM,
  titleKey: "form.object.editTitle",
};

function objectInitialValues(project: Project): FormValues {
  return {
    name: project.name,
    contract_sum: project.contractSum,
    paid_by_client: project.paidByClient,
    worker_payouts: project.workerPayouts,
    status: project.status,
    description: project.description,
    pause_reason: project.pauseReason,
    includes_vat: project.includesVat,
    includes_tax: project.includesTax,
    currency: project.currency,
  };
}

function DeleteDialog({
  projectName,
  onCancel,
  onConfirm,
}: {
  projectName: string;
  onCancel: () => void;
  onConfirm: () => Promise<void>;
}) {
  const { t } = useI18n();
  const [busy, setBusy] = useState(false);

  const confirm = async () => {
    setBusy(true);
    try {
      await onConfirm();
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-overlay px-6 backdrop-blur-sm animate-[fade-in_0.2s_ease-out]">
      <div className="w-full max-w-sm rounded-2xl border border-border bg-card p-6 shadow-2xl">
        <div className="flex items-start gap-3">
          <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-red-500/10 text-red-600 dark:text-red-400">
            <AlertTriangle className="h-5 w-5" />
          </span>
          <div className="min-w-0 flex-1">
            <h3 className="text-base font-semibold text-foreground">
              {t("detail.deleteConfirmTitle")}
            </h3>
            <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
              {t("detail.deleteConfirm", { name: projectName })}
            </p>
          </div>
          <button
            type="button"
            onClick={onCancel}
            className="rounded-full p-1.5 text-subtle transition hover:bg-secondary hover:text-foreground"
            aria-label={t("detail.cancel")}
          >
            <X className="h-4 w-4" />
          </button>
        </div>
        <div className="mt-5 flex gap-3">
          <button
            type="button"
            onClick={onCancel}
            disabled={busy}
            className="h-11 flex-1 rounded-xl border border-border text-sm font-medium text-soft transition hover:bg-secondary disabled:opacity-50"
          >
            {t("detail.cancel")}
          </button>
          <button
            type="button"
            onClick={confirm}
            disabled={busy}
            className="h-11 flex-1 rounded-xl bg-red-500 text-sm font-semibold text-white transition hover:bg-red-600 active:scale-[0.98] disabled:opacity-50"
          >
            {t("detail.delete")}
          </button>
        </div>
      </div>
    </div>
  );
}
