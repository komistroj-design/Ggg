import { Plus } from "lucide-react";

type FloatingAddButtonProps = {
  label: string;
  onClick: () => void;
};

export default function FloatingAddButton({ label, onClick }: FloatingAddButtonProps) {
  return (
    <div className="pointer-events-none fixed inset-x-0 bottom-0 z-40 mx-auto flex w-full max-w-md justify-end px-5 pb-[calc(1.5rem+env(safe-area-inset-bottom))]">
      <button
        type="button"
        onClick={onClick}
        aria-label={label}
        className="pointer-events-auto flex h-14 items-center gap-2 rounded-full bg-primary pl-4 pr-5 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/20 transition hover:bg-primary/90 active:scale-95"
      >
        <Plus className="h-5 w-5" />
        {label}
      </button>
    </div>
  );
}
