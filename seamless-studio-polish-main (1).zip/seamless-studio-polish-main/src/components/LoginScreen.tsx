import { useState, type FormEvent } from "react";
import { HardHat, Loader2, Mail, Lock } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useI18n } from "@/lib/i18n";
import { lovable } from "@/integrations/lovable/index";
import "@lovable.dev/cloud-auth-js/styles.css";

const GOOGLE_LOGO = (
  <svg
    aria-hidden="true"
    width="18"
    height="18"
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
  >
    <path
      fill="#4285F4"
      d="M23.49 12.27c0-.79-.07-1.54-.19-2.27H12v4.51h6.47c-.29 1.48-1.14 2.73-2.4 3.58v3h3.86c2.26-2.09 3.56-5.17 3.56-8.82z"
    />
    <path
      fill="#34A853"
      d="M12 24c3.24 0 5.95-1.08 7.93-2.91l-3.86-3c-1.08.72-2.45 1.16-4.07 1.16-3.13 0-5.78-2.11-6.73-4.96H1.29v3.09C3.26 21.3 7.31 24 12 24z"
    />
    <path
      fill="#FBBC05"
      d="M5.27 14.29c-.25-.72-.38-1.49-.38-2.29s.14-1.57.38-2.29V6.62H1.29C.47 8.24 0 10.06 0 12s.47 3.76 1.29 5.38l3.98-3.09z"
    />
    <path
      fill="#EA4335"
      d="M12 4.75c1.77 0 3.35.61 4.6 1.8l3.42-3.42C17.95 1.19 15.24 0 12 0 7.31 0 3.26 2.7 1.29 6.62l3.98 3.09c.95-2.85 3.6-4.96 6.73-4.96z"
    />
  </svg>
);

export default function LoginScreen() {
  const { signInWithEmail, signUpWithEmail, sendPasswordReset } = useAuth();
  const { t } = useI18n();
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [pending, setPending] = useState(false);

  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    setError(null);
    setSuccess(null);

    const trimmedEmail = email.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      setError(t("auth.errorEmail"));
      return;
    }
    if (password.length < 6) {
      setError(t("auth.errorPassword"));
      return;
    }

    setPending(true);
    try {
      if (mode === "signin") {
        await signInWithEmail(trimmedEmail, password);
      } else {
        await signUpWithEmail(trimmedEmail, password);
        setSuccess(t("auth.success"));
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "";
      if (message.includes("Invalid login credentials") || message.includes("invalid")) {
        setError(t("auth.errorInvalid"));
      } else if (
        message.includes("already") ||
        message.includes("registered") ||
        message.includes("exists")
      ) {
        setError(t("auth.errorExists"));
      } else {
        setError(t("auth.errorGeneric"));
      }
    } finally {
      setPending(false);
    }
  };

  const handleOAuth = async (provider: "google" | "lovable") => {
    setError(null);
    setSuccess(null);
    const result = await lovable.auth.signInWithOAuth(provider, {
      redirect_uri: window.location.origin,
    });
    if (result.error) setError(t("auth.errorGeneric"));
  };

  const handleForgot = async () => {
    setError(null);
    setSuccess(null);
    const trimmedEmail = email.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(trimmedEmail)) {
      setError(t("auth.errorEmail"));
      return;
    }
    setPending(true);
    try {
      await sendPasswordReset(trimmedEmail);
      setSuccess(t("auth.resetSent"));
    } catch {
      setError(t("auth.errorGeneric"));
    } finally {
      setPending(false);
    }
  };

  const switchMode = () => {
    setMode((prev) => (prev === "signin" ? "signup" : "signin"));
    setError(null);
    setSuccess(null);
  };

  const inputClass =
    "h-12 w-full rounded-xl border border-border bg-background pl-11 pr-4 text-base text-foreground placeholder:text-faint transition focus:border-primary/60 focus:outline-none focus:ring-2 focus:ring-primary/20 disabled:opacity-60";

  return (
    <div className="min-h-dvh bg-background text-foreground antialiased">
      <div className="mx-auto flex min-h-dvh w-full max-w-md flex-col items-center justify-center px-6 py-10">
        <div className="flex flex-col items-center text-center">
          <span className="flex h-16 w-16 items-center justify-center rounded-2xl bg-primary text-primary-foreground shadow-lg shadow-primary/20">
            <HardHat className="h-8 w-8" />
          </span>
          <h1 className="mt-6 text-2xl font-bold tracking-tight">{t("auth.welcome")}</h1>
          <p className="mt-2 max-w-xs text-sm leading-relaxed text-muted-foreground">
            {t("auth.subtitle")}
          </p>
        </div>

        <form onSubmit={handleSubmit} className="mt-10 flex w-full flex-col gap-4">
          <div className="flex rounded-xl bg-card p-1">
            <button
              type="button"
              onClick={() => {
                setMode("signin");
                setError(null);
                setSuccess(null);
              }}
              className={`h-10 flex-1 rounded-lg text-sm font-medium transition ${mode === "signin" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
            >
              {t("auth.signIn")}
            </button>
            <button
              type="button"
              onClick={() => {
                setMode("signup");
                setError(null);
                setSuccess(null);
              }}
              className={`h-10 flex-1 rounded-lg text-sm font-medium transition ${mode === "signup" ? "bg-primary text-primary-foreground" : "text-muted-foreground hover:text-foreground"}`}
            >
              {t("auth.signUp")}
            </button>
          </div>

          <label className="flex flex-col gap-1.5">
            <span className="text-sm text-muted-foreground">{t("auth.email")}</span>
            <div className="relative">
              <Mail className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
              <input
                type="email"
                inputMode="email"
                autoComplete="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                disabled={pending}
                placeholder="user@example.com"
                className={inputClass}
              />
            </div>
          </label>

          <label className="flex flex-col gap-1.5">
            <span className="text-sm text-muted-foreground">{t("auth.password")}</span>
            <div className="relative">
              <Lock className="pointer-events-none absolute left-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-faint" />
              <input
                type="password"
                autoComplete={mode === "signin" ? "current-password" : "new-password"}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                disabled={pending}
                placeholder="••••••"
                className={inputClass}
              />
            </div>
            {mode === "signup" ? (
              <span className="text-xs text-faint">{t("auth.passwordHint")}</span>
            ) : (
              <button
                type="button"
                onClick={() => void handleForgot()}
                disabled={pending}
                className="self-end text-xs text-muted-foreground transition hover:text-foreground"
              >
                {t("auth.forgot")}
              </button>
            )}
          </label>

          {error && (
            <p className="rounded-xl bg-red-500/10 px-4 py-3 text-sm text-red-700 dark:text-red-300">
              {error}
            </p>
          )}
          {success && (
            <p className="rounded-xl bg-emerald-500/10 px-4 py-3 text-sm text-emerald-700 dark:text-emerald-300">
              {success}
            </p>
          )}

          <button
            type="submit"
            disabled={pending}
            className="flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-primary font-semibold text-primary-foreground transition hover:bg-primary/90 active:scale-[0.98] disabled:opacity-70"
          >
            {pending && <Loader2 className="h-4 w-4 animate-spin" />}
            {pending
              ? mode === "signin"
                ? t("auth.signingIn")
                : t("auth.signingUp")
              : mode === "signin"
                ? t("auth.signInBtn")
                : t("auth.signUpBtn")}
          </button>

          <button
            type="button"
            onClick={switchMode}
            className="text-center text-sm text-muted-foreground transition hover:text-amber-700 dark:hover:text-amber-300"
          >
            {mode === "signin" ? t("auth.noAccount") : t("auth.haveAccount")}
          </button>

          <div className="flex items-center gap-3 text-xs text-subtle">
            <span className="h-px flex-1 bg-border" />
            {t("auth.or")}
            <span className="h-px flex-1 bg-border" />
          </div>

          <button
            type="button"
            onClick={() => void handleOAuth("google")}
            className="google-auth-button flex h-12 w-full items-center justify-center gap-2.5 rounded-xl border px-3 text-sm font-medium transition active:scale-[0.98]"
          >
            {GOOGLE_LOGO}
            {t("auth.google")}
          </button>
          <button
            type="button"
            onClick={() => void handleOAuth("lovable")}
            className="lovable-auth-button w-full"
          >
            {t("auth.lovable")}
          </button>
        </form>
      </div>
    </div>
  );
}
