import { ChevronLeft, Settings as SettingsIcon, Globe, Palette, Coins, LogOut } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useI18n } from "@/lib/i18n";
import { CURRENCIES } from "@/lib/currency";
import type { CurrencyCode, Language, ThemePref } from "@/lib/types";

type SettingsScreenProps = {
  onBack: () => void;
};

export default function SettingsScreen({ onBack }: SettingsScreenProps) {
  const { settings, setSettings, signOut } = useAuth();
  const { t, lang } = useI18n();

  const current = settings ?? {
    language: "ru" as Language,
    theme: "dark" as ThemePref,
    currency: "₽" as CurrencyCode,
  };

  return (
    <div className="flex flex-col gap-6 pb-10 animate-[fade-in_0.3s_ease-out]">
      <div className="flex items-center gap-3">
        <button
          type="button"
          onClick={onBack}
          className="-ml-2 flex h-10 w-10 items-center justify-center rounded-full text-soft transition hover:bg-secondary hover:text-foreground"
          aria-label={t("nav.back")}
        >
          <ChevronLeft className="h-6 w-6" />
        </button>
        <h2 className="flex items-center gap-2 text-lg font-semibold text-foreground">
          <SettingsIcon className="h-5 w-5 text-primary" />
          {t("settings.title")}
        </h2>
      </div>

      <Section icon={<Globe className="h-4 w-4" />} title={t("settings.language")}>
        <SegmentedOptions
          options={[
            { value: "ru", label: t("settings.russian") },
            { value: "en", label: t("settings.english") },
          ]}
          value={current.language}
          onChange={(value) => void setSettings({ ...current, language: value as Language })}
        />
      </Section>

      <Section icon={<Palette className="h-4 w-4" />} title={t("settings.theme")}>
        <SegmentedOptions
          options={[
            { value: "dark", label: t("settings.dark") },
            { value: "light", label: t("settings.light") },
            { value: "system", label: t("settings.system") },
          ]}
          value={current.theme}
          onChange={(value) => void setSettings({ ...current, theme: value as ThemePref })}
        />
      </Section>

      <Section icon={<Coins className="h-4 w-4" />} title={t("settings.currency")}>
        <SegmentedOptions
          options={CURRENCIES.map((c) => ({ value: c.code, label: c.code }))}
          value={current.currency}
          onChange={(value) => void setSettings({ ...current, currency: value as CurrencyCode })}
        />
      </Section>

      <div className="mt-2">
        <p className="mb-2 px-1 text-xs font-medium uppercase tracking-wider text-subtle">
          {t("settings.account")}
        </p>
        <button
          type="button"
          onClick={() => void signOut()}
          className="flex w-full items-center gap-3 rounded-2xl border border-border bg-card/70 px-4 py-3.5 text-sm font-medium text-red-600 dark:text-red-400 transition hover:border-red-500/30 hover:bg-red-500/5 active:scale-[0.98]"
        >
          <LogOut className="h-4 w-4" />
          {t("settings.signOut")}
        </button>
      </div>
    </div>
  );
}

function Section({
  icon,
  title,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <section className="rounded-2xl border border-border bg-card/70 p-4">
      <div className="mb-3 flex items-center gap-2 text-muted-foreground">
        <span className="text-primary">{icon}</span>
        <span className="text-sm font-medium">{title}</span>
      </div>
      {children}
    </section>
  );
}

type SegOption = { value: string; label: string };

function SegmentedOptions({
  options,
  value,
  onChange,
}: {
  options: SegOption[];
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <div className="flex flex-wrap gap-1 rounded-xl bg-background p-1">
      {options.map((option) => {
        const active = option.value === value;
        return (
          <button
            key={option.value}
            type="button"
            onClick={() => onChange(option.value)}
            className={`flex h-10 flex-1 items-center justify-center rounded-lg px-3 text-sm font-medium transition ${
              active
                ? "bg-primary text-primary-foreground"
                : "text-muted-foreground hover:text-foreground"
            }`}
          >
            {option.label}
          </button>
        );
      })}
    </div>
  );
}
