import { useCallback, useEffect, useState } from "react";
import {
  deleteEntry,
  deleteObject,
  fetchSiteData,
  insertEntry,
  insertObject,
  updateMaterialStatus,
  updateObject,
  updateWorkPaid,
  type EntryInput,
  type ObjectInput,
} from "@/lib/database";
import type { EntryKind, SiteData } from "@/lib/types";

type State =
  | { status: "loading" }
  | { status: "error"; message: string }
  | { status: "ready"; data: SiteData };

export function useSiteData(enabled: boolean) {
  const [state, setState] = useState<State>({ status: "loading" });

  const reload = useCallback(async () => {
    try {
      const data = await fetchSiteData();
      setState({ status: "ready", data });
    } catch (err) {
      const message = err instanceof Error ? err.message : "Не удалось загрузить данные";
      setState((prev) => (prev.status === "ready" ? prev : { status: "error", message }));
    }
  }, []);

  useEffect(() => {
    if (!enabled) return;
    setState({ status: "loading" });
    void reload();
  }, [reload, enabled]);

  const addObject = useCallback(
    async (values: ObjectInput) => {
      await insertObject(values);
      await reload();
    },
    [reload],
  );

  const editObject = useCallback(
    async (id: string, values: ObjectInput) => {
      await updateObject(id, values);
      await reload();
    },
    [reload],
  );

  const removeObject = useCallback(
    async (id: string) => {
      await deleteObject(id);
      await reload();
    },
    [reload],
  );

  const addEntry = useCallback(
    async (kind: EntryKind, objectId: string, values: EntryInput) => {
      await insertEntry(kind, objectId, values);
      await reload();
    },
    [reload],
  );

  const setMaterialStatus = useCallback(
    async (id: string, status: string) => {
      await updateMaterialStatus(id, status);
      await reload();
    },
    [reload],
  );

  const setWorkPaid = useCallback(
    async (id: string, paid: boolean) => {
      await updateWorkPaid(id, paid);
      await reload();
    },
    [reload],
  );

  const removeEntry = useCallback(
    async (kind: EntryKind, id: string) => {
      await deleteEntry(kind, id);
      await reload();
    },
    [reload],
  );

  return {
    state,
    reload,
    addObject,
    editObject,
    removeObject,
    addEntry,
    setMaterialStatus,
    setWorkPaid,
    removeEntry,
  };
}
