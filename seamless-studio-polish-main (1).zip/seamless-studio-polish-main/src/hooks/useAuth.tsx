import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/lib/supabase";
import { fetchSettings, upsertSettings } from "@/lib/database";
import type { Language, ThemePref, CurrencyCode, Settings } from "@/lib/types";

type AuthContextValue = {
  session: Session | null;
  user: User | null;
  loading: boolean;
  settings: Settings | null;
  setSettings: (settings: Settings) => void;
  signInWithEmail: (email: string, password: string) => Promise<void>;
  signUpWithEmail: (email: string, password: string) => Promise<void>;
  sendPasswordReset: (email: string) => Promise<void>;
  signOut: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | null>(null);

const DEFAULT_SETTINGS: Settings = { language: "ru", theme: "dark", currency: "₽" };

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const [settings, setSettingsState] = useState<Settings | null>(null);

  useEffect(() => {
    let mounted = true;

    supabase.auth.getSession().then(({ data }) => {
      if (!mounted) return;
      setSession(data.session);
      if (data.session?.user) {
        void loadSettings(data.session.user.id);
      } else {
        setLoading(false);
      }
    });

    const { data: sub } = supabase.auth.onAuthStateChange((_event, newSession) => {
      if (!mounted) return;
      setSession(newSession);
      // Defer database calls: awaiting them inside this callback can lock the auth client.
      setTimeout(() => {
        if (!mounted) return;
        if (newSession?.user) {
          void loadSettings(newSession.user.id);
        } else {
          setSettingsState(null);
          setLoading(false);
        }
      }, 0);
    });

    return () => {
      mounted = false;
      sub.subscription.unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function loadSettings(userId: string) {
    const stored = await fetchSettings(userId);
    if (stored) {
      setSettingsState({
        language: stored.language as Language,
        theme: stored.theme as ThemePref,
        currency: stored.currency as CurrencyCode,
      });
    } else {
      setSettingsState(DEFAULT_SETTINGS);
      await upsertSettings(userId, DEFAULT_SETTINGS);
    }
    setLoading(false);
  }

  async function setSettings(next: Settings) {
    setSettingsState(next);
    if (session?.user) {
      await upsertSettings(session.user.id, next);
    }
  }

  async function signInWithEmail(email: string, password: string) {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    if (error) throw error;
  }

  async function signUpWithEmail(email: string, password: string) {
    const { error } = await supabase.auth.signUp({
      email,
      password,
      options: { emailRedirectTo: window.location.origin },
    });
    if (error) throw error;
  }

  async function sendPasswordReset(email: string) {
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo: `${window.location.origin}/reset-password`,
    });
    if (error) throw error;
  }

  async function signOut() {
    await supabase.auth.signOut();
    setSettingsState(null);
  }

  const value = useMemo<AuthContextValue>(
    () => ({
      session,
      user: session?.user ?? null,
      loading,
      settings,
      setSettings,
      signInWithEmail,
      signUpWithEmail,
      sendPasswordReset,
      signOut,
    }),
    [session, loading, settings],
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
