import { useEffect, useState } from "react";
import type { ThemePref } from "@/lib/types";

export const THEME_STORAGE_KEY = "komistroj-theme";

export function resolveIsDark(theme: ThemePref, systemDark: boolean): boolean {
  return theme === "dark" || (theme === "system" && systemDark);
}

export function applyTheme(isDark: boolean, root: HTMLElement = document.documentElement) {
  root.classList.toggle("dark", isDark);
  root.style.colorScheme = isDark ? "dark" : "light";
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute("content", isDark ? "#09090b" : "#f4f4f5");
}

/** Keeps the <html> "dark" class in sync with the chosen theme. Pass null while settings load. */
export function useTheme(theme: ThemePref | null) {
  const [systemDark, setSystemDark] = useState(false);

  useEffect(() => {
    const media = window.matchMedia("(prefers-color-scheme: dark)");
    setSystemDark(media.matches);
    const handler = (e: MediaQueryListEvent) => setSystemDark(e.matches);
    media.addEventListener("change", handler);
    return () => media.removeEventListener("change", handler);
  }, []);

  useEffect(() => {
    if (theme === null) return;
    applyTheme(resolveIsDark(theme, systemDark));
    try {
      window.localStorage.setItem(THEME_STORAGE_KEY, theme);
    } catch {
      // storage unavailable: the class is still applied for this session
    }
  }, [theme, systemDark]);
}
