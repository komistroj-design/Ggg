-- Construction sites (objects), their materials and works, and per-user settings.
-- Every row belongs to the signed-in user: user_id defaults to auth.uid() so inserts
-- that omit it still pass the owner-only access rules.

CREATE TABLE public.objects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  name text NOT NULL CHECK (char_length(btrim(name)) BETWEEN 1 AND 200),
  contract_sum numeric NOT NULL DEFAULT 0 CHECK (contract_sum >= 0),
  paid_by_client numeric NOT NULL DEFAULT 0 CHECK (paid_by_client >= 0),
  worker_payouts numeric NOT NULL DEFAULT 0 CHECK (worker_payouts >= 0),
  description text NOT NULL DEFAULT '' CHECK (char_length(description) <= 2000),
  status text NOT NULL DEFAULT 'В работе' CHECK (status IN ('В работе', 'На паузе', 'Выполнено')),
  pause_reason text NOT NULL DEFAULT '',
  includes_vat boolean NOT NULL DEFAULT false,
  includes_tax boolean NOT NULL DEFAULT false,
  currency text NOT NULL DEFAULT '₽',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX objects_user_id_idx ON public.objects (user_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.objects TO authenticated;
GRANT ALL ON public.objects TO service_role;
ALTER TABLE public.objects ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_objects" ON public.objects FOR SELECT TO authenticated
  USING (auth.uid() = user_id);
CREATE POLICY "insert_own_objects" ON public.objects FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_objects" ON public.objects FOR UPDATE TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_objects" ON public.objects FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

CREATE TABLE public.materials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  object_id uuid NOT NULL REFERENCES public.objects(id) ON DELETE CASCADE,
  name text NOT NULL CHECK (char_length(btrim(name)) BETWEEN 1 AND 200),
  unit text NOT NULL DEFAULT '' CHECK (char_length(unit) <= 30),
  quantity numeric NOT NULL DEFAULT 0 CHECK (quantity >= 0),
  price numeric NOT NULL DEFAULT 0 CHECK (price >= 0),
  total numeric GENERATED ALWAYS AS (quantity * price) STORED,
  status text NOT NULL DEFAULT 'Планируется' CHECK (status IN ('Планируется', 'Закуплено и доставлено')),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX materials_object_id_idx ON public.materials (object_id);
CREATE INDEX materials_user_id_idx ON public.materials (user_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.materials TO authenticated;
GRANT ALL ON public.materials TO service_role;
ALTER TABLE public.materials ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_materials" ON public.materials FOR SELECT TO authenticated
  USING (auth.uid() = user_id);
CREATE POLICY "insert_own_materials" ON public.materials FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = user_id
    AND EXISTS (SELECT 1 FROM public.objects o WHERE o.id = object_id AND o.user_id = auth.uid())
  );
CREATE POLICY "update_own_materials" ON public.materials FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (
    auth.uid() = user_id
    AND EXISTS (SELECT 1 FROM public.objects o WHERE o.id = object_id AND o.user_id = auth.uid())
  );
CREATE POLICY "delete_own_materials" ON public.materials FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

CREATE TABLE public.works (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid(),
  object_id uuid NOT NULL REFERENCES public.objects(id) ON DELETE CASCADE,
  name text NOT NULL CHECK (char_length(btrim(name)) BETWEEN 1 AND 200),
  unit text NOT NULL DEFAULT '' CHECK (char_length(unit) <= 30),
  quantity numeric NOT NULL DEFAULT 0 CHECK (quantity >= 0),
  price numeric NOT NULL DEFAULT 0 CHECK (price >= 0),
  total numeric GENERATED ALWAYS AS (quantity * price) STORED,
  paid boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX works_object_id_idx ON public.works (object_id);
CREATE INDEX works_user_id_idx ON public.works (user_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.works TO authenticated;
GRANT ALL ON public.works TO service_role;
ALTER TABLE public.works ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_works" ON public.works FOR SELECT TO authenticated
  USING (auth.uid() = user_id);
CREATE POLICY "insert_own_works" ON public.works FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = user_id
    AND EXISTS (SELECT 1 FROM public.objects o WHERE o.id = object_id AND o.user_id = auth.uid())
  );
CREATE POLICY "update_own_works" ON public.works FOR UPDATE TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (
    auth.uid() = user_id
    AND EXISTS (SELECT 1 FROM public.objects o WHERE o.id = object_id AND o.user_id = auth.uid())
  );
CREATE POLICY "delete_own_works" ON public.works FOR DELETE TO authenticated
  USING (auth.uid() = user_id);

CREATE TABLE public.user_settings (
  user_id uuid PRIMARY KEY DEFAULT auth.uid(),
  language text NOT NULL DEFAULT 'ru' CHECK (language IN ('ru', 'en')),
  theme text NOT NULL DEFAULT 'dark' CHECK (theme IN ('dark', 'light', 'system')),
  currency text NOT NULL DEFAULT '₽' CHECK (currency IN ('$', '€', '₽', 'BYN')),
  updated_at timestamptz NOT NULL DEFAULT now()
);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.user_settings TO authenticated;
GRANT ALL ON public.user_settings TO service_role;
ALTER TABLE public.user_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "select_own_settings" ON public.user_settings FOR SELECT TO authenticated
  USING (auth.uid() = user_id);
CREATE POLICY "insert_own_settings" ON public.user_settings FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = user_id);
CREATE POLICY "update_own_settings" ON public.user_settings FOR UPDATE TO authenticated
  USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE POLICY "delete_own_settings" ON public.user_settings FOR DELETE TO authenticated
  USING (auth.uid() = user_id);
