<!-- LOVABLE:BEGIN -->
> [!IMPORTANT]
> This project is connected to [Lovable](https://lovable.dev). Avoid rewriting
> published git history — force pushing, or rebasing/amending/squashing commits
> that are already pushed — as it rewrites history on Lovable's side and the
> user will likely lose their project history.
>
> Commits you push to the connected branch sync back to Lovable and show up in
> the editor, so keep the branch in a working state.

## What Lovable manages

Rules outside this block are the project's own. Change the pieces below in
Lovable, not by hand. With the [Lovable MCP](https://mcp.lovable.dev)
connected, `send_message` asks Lovable to do it; otherwise ask the user to
use the editor.

- **Database.** Do not add or edit `supabase/migrations/` or `drizzle/`.
  Ask Lovable to change the schema.
- **Generated files.** Do not edit a file whose header says it is automatically
  generated.
- **AI gateway.** Keep model calls on Lovable's gateway, and keep
  `LOVABLE_API_KEY` out of browser code.
- **Connectors.** Lovable provides native connectors. `list_connectors` shows
  which are enabled; `add_connector` only returns the dashboard link. When a
  connector is enabled, calls go through the connector gateway and need
  `LOVABLE_API_KEY`. When Lovable does not provide one, users can bring their
  own key and store it in Secrets.
- **Secrets.** Lovable manages them. Do not put secret values in the repo.
<!-- LOVABLE:END -->

## Project rules

- The whole app is one client-driven screen at `/` (`src/components/KomistrojApp.tsx`) that switches between list, detail and settings with React state; only standalone pages like `/reset-password` get their own route. Why: ported from a single-screen mobile-style app.
- Colours come only from semantic tokens in `src/styles.css` (including `soft`, `subtle`, `faint`, `border-strong`, `overlay`); accent text pairs a light shade with a `dark:` shade. Why: both light and dark themes must stay readable.
- The `dark` class on `<html>` is owned by `useTheme` plus the inline init script in `__root.tsx`, which share the `komistroj-theme` localStorage key. Why: the theme applies before first paint and follows the saved setting.
- Every user-owned table has `user_id uuid NOT NULL DEFAULT auth.uid()` with owner-only policies, and the client also sends `user_id` on insert. Why: inserts must never fail the ownership check.
- Child rows (materials, works) may only be inserted under an object the same user owns. Why: blocks writing into someone else's object.
