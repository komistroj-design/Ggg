# Seamless Studio Polish

Fix three specific bugs in the current codebase:

1. DATABASE INSERT ERROR ("Не удалось сохранить запись"): Check the Supabase schema and RLS (Row Level Security) policies for the objects, materials, and works tables. Ensure the `user_id` column exists (defaulting to `auth.uid()`), RLS policies allow authenticated users to INSERT, SELECT, UPDATE, and DELETE their own rows, and the frontend form sends the exact expected data types (converting empty number inputs to `0`).

2. LIGHT THEME FIX: Fix the Theme Picker in Settings. Ensure selecting "Light" properly removes the `dark` class from the root `html` element and applies clean light-mode background and text colors across all screens, cards, and inputs.

3. WATERMARK REMOVAL: Force hide the floating "Made in Bolt" badge using CSS (`display: none !important` on any fixed bottom-right badges/iframes injected by Bolt) so it does not overlap the "Сохранить" button.

This project was built with [Lovable](https://lovable.dev).

**Live app**: https://seamless-studio-polish.lovable.app

## Build with Lovable

Continue developing this project in the [Lovable editor](https://lovable.dev/projects/655b3a41-46a2-470c-8a49-030509d6db78).

- **Ship faster**: describe what you want to build and Lovable handles the code.
- **Stay in sync**: every change made in Lovable is committed straight to this repository.
- **Full ownership**: this code is yours. Push to `main` on GitHub and your changes sync back into Lovable, ready for your next prompt.

## Development

Prefer working locally? You need Node.js and npm — [install with nvm](https://github.com/nvm-sh/nvm#installing-and-updating).

```sh
git clone <this-repository-url>
cd <repository-name>
npm i
npm run dev
```
