<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# Путеводная звезда

Подрядчики точно знают, во что им обходится каждый объект

## Метрика

Объекты, по которым записан материал или работа, за каждую неделю
